# ÉCLAT — Direction artistique du mini-jeu

## Source de vérité
Cette refonte traduit le brandboard fourni dans `Presentation_finale-PAO.pdf` : **créativité, précision, émerveillement**, avec la rencontre de la vibration JBL et de la délicatesse artisanale de Maison Fragile.

## Système visuel appliqué

| Élément | Décision de jeu |
| --- | --- |
| Palette | Cyan poudre `#8ecfd6`, sauge `#889f92`, corail `#e87c67`, abricot `#ef9b5b`, rose poudré `#eda2a2`, porcelaine ivoire. |
| Typographie | `Fredoka` pour les titres doux et pleins ; `Nunito Sans` pour l’interface. Ce duo web libre reprend l’intention ronde de **Kit Rounded** sans introduire de dépendance de police propriétaire. |
| Matières | Porcelaine mate, bois de bouleau clair, textile de tapis tufté, meubles laqués pastel, lumière de journée chaude. |
| Formes | Pièces de puzzle imbriquées avec onglets et encoches réels, coins généreusement arrondis, volumes jouets réalistes et accessibles. Les éléments ronds ne sont employés que lorsqu’ils correspondent à un objet de chambre crédible (lampe, balle, poignée). |
| Ton | Lumineux, tactile, contemporain et familial — jamais nocturne, gothique ou féerique sombre. |

## Chambre 3D
La scène Babylon ne s’appuie plus sur les anciennes façades 2D de mobilier. Chaque élément principal est composé de volumes 3D et de détails séparés : lit avec sommier, matelas, couette, oreillers, tête de lit, pieds et table de nuit ; bureau avec caisson, tiroirs, chaise à roulettes, pot à crayons, feuilles et lampe ; armoire, bibliothèque garnie, coffre à jouets, fauteuil, table d’appoint, fenêtre avec rideaux, tapis, mobile, maison de poupée et tableau mural. Les pièces de puzzle sont fabriquées par booléens CSG dans Babylon : la forme a donc de vrais onglets, de vraies encoches et une épaisseur lumineuse.

## Onboarding
Avant l’entrée dans la chambre, une fenêtre explique explicitement les deux parcours : **ZQSD/WASD/flèches + souris** sur ordinateur, **joystick gauche + glissement à droite** sur téléphone. Le bouton **RECUEILLIR** est aussi annoncé.
