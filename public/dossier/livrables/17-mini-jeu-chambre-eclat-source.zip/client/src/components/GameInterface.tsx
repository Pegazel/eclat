import { useEffect, useRef, useState } from "react";
import type { GameSnapshot } from "@/game/types";
import { assets } from "@/game/assets";

const initial: GameSnapshot = {
  phase: "intro",
  fragments: 0,
  hint: "La chambre attend ses couleurs…",
  canInteract: false,
};

type KeychainMoment = { id: number; label: string; message: string };
type Stick = { x: number; y: number };
type FinalClue = { symbol: string; label: string; number: string };
type FinalReward = { clue: FinalClue | null; issued: number };

const clueSequence: FinalClue[] = [
  { symbol: "☾", label: "Lune", number: "03" },
  { symbol: "☀", label: "Soleil", number: "17" },
  { symbol: "✦", label: "Étoile", number: "08" },
  { symbol: "☁", label: "Nuage", number: "24" },
];

const clueStorageKey = "eclat-clue-distribution-v1";

function awardNextClue(): FinalReward {
  try {
    const stored = Number(window.localStorage.getItem(clueStorageKey));
    const issued = Number.isFinite(stored) ? Math.min(Math.max(stored, 0), clueSequence.length) : 0;
    if (issued === clueSequence.length) return { clue: null, issued };
    window.localStorage.setItem(clueStorageKey, String(issued + 1));
    return { clue: clueSequence[issued], issued: issued + 1 };
  } catch {
    return { clue: clueSequence[0], issued: 1 };
  }
}

function sendCommand(command: "start" | "reset" | "interact") {
  window.dispatchEvent(new CustomEvent("eclat:command", { detail: command }));
}

function sendMovement(forward: number, right: number) {
  window.dispatchEvent(new CustomEvent("eclat:move", { detail: { forward, right } }));
}

function sendAudio(muted: boolean, volume: number) {
  window.dispatchEvent(new CustomEvent("eclat:audio", { detail: { muted, volume } }));
}

export function GameInterface() {
  const [state, setState] = useState<GameSnapshot>(initial);
  const [showHelp, setShowHelp] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [cinematic, setCinematic] = useState<KeychainMoment | null>(null);
  const [audioOpen, setAudioOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(.72);
  const [stick, setStick] = useState<Stick>({ x: 0, y: 0 });
  const [finalReward, setFinalReward] = useState<FinalReward | null>(null);
  const cinematicTimer = useRef<number | null>(null);
  const rewardIssuedForCurrentRun = useRef(false);

  useEffect(() => {
    const onState = (event: Event) => setState((event as CustomEvent<GameSnapshot>).detail);
    const onKeychain = (event: Event) => {
      const moment = (event as CustomEvent<KeychainMoment>).detail;
      if (cinematicTimer.current) window.clearTimeout(cinematicTimer.current);
      setCinematic(moment);
      cinematicTimer.current = window.setTimeout(() => setCinematic(null), 2600);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === "e" && state.phase === "exploring") sendCommand("interact");
    };
    window.addEventListener("eclat:state", onState);
    window.addEventListener("eclat:keychain", onKeychain);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("eclat:state", onState);
      window.removeEventListener("eclat:keychain", onKeychain);
      window.removeEventListener("keydown", onKey);
      if (cinematicTimer.current) window.clearTimeout(cinematicTimer.current);
    };
  }, [state.phase]);

  useEffect(() => {
    if (state.phase !== "complete") {
      rewardIssuedForCurrentRun.current = false;
      return;
    }
    if (!rewardIssuedForCurrentRun.current) {
      rewardIssuedForCurrentRun.current = true;
      setFinalReward(awardNextClue());
    }
  }, [state.phase]);

  const exploring = state.phase === "exploring" || state.phase === "awakening";
  const moveStick = (event: React.PointerEvent<HTMLDivElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    const rawX = event.clientX - (bounds.left + bounds.width / 2);
    const rawY = event.clientY - (bounds.top + bounds.height / 2);
    const radius = bounds.width * .31;
    const distance = Math.hypot(rawX, rawY) || 1;
    const scale = Math.min(1, radius / distance);
    const x = rawX * scale;
    const y = rawY * scale;
    setStick({ x, y });
    sendMovement(-y / radius, x / radius);
  };
  const releaseStick = () => {
    setStick({ x: 0, y: 0 });
    sendMovement(0, 0);
  };
  const applyAudio = (nextMuted: boolean, nextVolume: number) => {
    setMuted(nextMuted);
    setVolume(nextVolume);
    sendAudio(nextMuted, nextVolume);
  };
  const beginAdventure = () => {
    setShowTutorial(false);
    sendCommand("start");
  };
  const restartForNextGroup = () => {
    setFinalReward(null);
    sendCommand("reset");
  };

  return (
    <div className="game-ui" aria-live="polite">
      {exploring && (
        <>
          <header className="brand-mark" aria-label="Puzzle Éclat">
            <span className="brand-spark" />
            <span>PUZZLE ÉCLAT</span>
          </header>

          <div className="fragment-meter" aria-label={`${state.fragments} fragments sur 5`}>
            <span className="meter-label">ÉCLATS RETROUVÉS</span>
            <span className="meter-value">{state.fragments} <i>/</i> 5</span>
            <span className="meter-dots">
              {[0, 1, 2, 3, 4].map((index) => <b key={index} className={index < state.fragments ? "lit" : ""} />)}
            </span>
          </div>

          <div className={`reticle ${state.canInteract ? "active" : ""}`}><span /></div>
          <div className={`story-toast ${state.hint ? "visible" : ""}`}>
            <span className="toast-spark">✦</span>
            <p>{state.hint}</p>
            {state.canInteract && <small>CLIQUE, TOUCHE OU APPUIE SUR E</small>}
          </div>

          <button className="help-control" onClick={() => setShowHelp((visible) => !visible)} aria-expanded={showHelp}>
            {showHelp ? "FERMER" : "COMMENT JOUER ?"}
          </button>
          {showHelp && (
            <aside className="help-card">
              <p><strong>Ordinateur</strong> — avance avec <kbd>Z</kbd><kbd>Q</kbd><kbd>S</kbd><kbd>D</kbd>, <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> ou les flèches. Utilise la souris pour regarder.</p>
              <p><strong>Téléphone</strong> — tiens le joystick à gauche, glisse à droite pour regarder, puis touche <b>RECUEILLIR</b> près d’un porte-clés.</p>
            </aside>
          )}

          <div className="audio-widget">
            <button className={`audio-control ${muted ? "muted" : ""}`} onClick={() => setAudioOpen((open) => !open)} aria-expanded={audioOpen} aria-label="Réglages sonores">
              {muted ? "◌" : "♪"} <span>SON</span>
            </button>
            {audioOpen && (
              <div className="audio-panel">
                <div className="audio-panel-top"><span>AMBIANCE</span><button onClick={() => applyAudio(!muted, volume)}>{muted ? "ACTIVER" : "COUPER"}</button></div>
                <input aria-label="Volume de l’ambiance" type="range" min="0" max="1" step="0.05" value={muted ? 0 : volume} onChange={(event) => applyAudio(Number(event.target.value) === 0, Number(event.target.value))} />
              </div>
            )}
          </div>

          <div className="touch-joystick" aria-label="Joystick de déplacement" onPointerDown={(event) => { event.currentTarget.setPointerCapture(event.pointerId); moveStick(event); }} onPointerMove={(event) => { if (event.currentTarget.hasPointerCapture(event.pointerId)) moveStick(event); }} onPointerUp={releaseStick} onPointerCancel={releaseStick}>
            <span className="touch-joystick-label">DÉPLACER</span>
            <i style={{ transform: `translate(${stick.x}px, ${stick.y}px)` }} />
          </div>
          <button className={`interact-control ${state.canInteract ? "ready" : ""}`} onPointerDown={(event) => { event.preventDefault(); sendCommand("interact"); }} aria-label="Recueillir l’Éclat">
            <span>✦</span><small>RECUEILLIR</small>
          </button>
          <button className="reset-control" onClick={() => sendCommand("reset")}>RECOMMENCER</button>
        </>
      )}

      {state.phase === "intro" && (
        <section className="intro-screen">
          <div className="intro-shapes" aria-hidden="true"><i /><i /><i /><i /></div>
          <div className="intro-content">
            <p className="eyebrow">PUZZLE ÉCLAT</p>
            <h1>LA CHAMBRE<br /><em>DES ÉCLATS</em></h1>
            <p className="intro-tagline">Construire. Illuminer. Rêver.</p>
            <button className="start-button" onClick={() => setShowTutorial(true)}><span>ENTRER DANS LA CHAMBRE</span><b>→</b></button>
            <p className="intro-caption">Une petite exploration à partager</p>
          </div>
        </section>
      )}

      {showTutorial && (
        <section className="tutorial-modal" role="dialog" aria-modal="true" aria-label="Comment se déplacer">
          <div className="tutorial-card">
            <span className="tutorial-chip">BIEN COMMENCER</span>
            <h2>Comment jouer&nbsp;?</h2>
            <div className="tutorial-choices">
              <article><span className="tutorial-icon keyboard-icon">⌨</span><div><strong>SUR ORDINATEUR</strong><p><b>ZQSD / WASD</b> ou les flèches pour avancer.<br />La <b>souris</b> pour regarder.</p></div></article>
              <article><span className="tutorial-icon joystick-icon">◉</span><div><strong>SUR TÉLÉPHONE</strong><p>Le <b>joystick à gauche</b> pour avancer.<br />Glisse à droite pour regarder.</p></div></article>
            </div>
            <p className="tutorial-note">Approche un porte-clés et utilise <b>RECUEILLIR</b> pour le garder.</p>
            <button className="tutorial-start" onClick={beginAdventure}>C’EST PARTI <b>→</b></button>
          </div>
        </section>
      )}

      {state.phase === "awakening" && <div className="awakening-copy"><span>✦</span><p>LA CHAMBRE S’ILLUMINE…</p></div>}

      {state.phase === "complete" && (
        <section className="ending-screen">
          <div className="ending-card">
            <span className="ending-star">✦</span><p className="eyebrow">PUZZLE ÉCLAT</p>
            <h2>La chambre<br />reprend vie.</h2><p className="ending-copy">Tu as réuni tous les éclats de couleur.</p>
            {finalReward?.clue ? (
              <div className="clue-card clue-reward">
                <span>NOUVEL INDICE <b>—</b> {finalReward.issued} / {clueSequence.length}</span>
                <div className="clue-token clue-token-large" aria-label={`${finalReward.clue.label} ${finalReward.clue.number}`}><b>{finalReward.clue.symbol}</b><strong>{finalReward.clue.number}</strong></div>
              </div>
            ) : (
              <div className="clue-card clue-complete"><span>MISSION TERMINÉE</span><strong>LES 4 INDICES ONT ÉTÉ DISTRIBUÉS</strong></div>
            )}
            <p className="ending-footer">{finalReward?.clue ? "Note cet indice et pars dans le labyrinthe." : "Les quatre groupes peuvent maintenant chercher chacun leur destination."}</p>
            <button className="continue-button" onClick={restartForNextGroup}>{finalReward?.clue ? "GROUPE SUIVANT" : "REJOUER"} <b>↗</b></button>
          </div>
        </section>
      )}

      {cinematic && (
        <section className="collection-cinematic" aria-label={`Porte-clés découvert : ${cinematic.label}`}>
          <div className="collection-flash" />
          <div className="collection-object"><div className="collection-halo" /><img src={assets.keychainTextures[cinematic.id - 1]} alt={`Porte-clés puzzle ${cinematic.label}`} /></div>
          <div className="collection-copy"><span>PORTE-CLÉS TROUVÉ</span><strong>{cinematic.label}</strong><p>{cinematic.message}</p></div>
        </section>
      )}
    </div>
  );
}
