import { Engine } from "@babylonjs/core/Engines/engine";
import { Scene } from "@babylonjs/core/scene";
import { GameWorld } from "@/game/GameWorld";

export interface GameHandle {
  scene: Scene;
  dispose(): void;
}

export async function createGameScene(engine: Engine, canvas: HTMLCanvasElement): Promise<GameHandle> {
  const scene = new Scene(engine);
  const world = new GameWorld(scene, canvas);

  scene.onBeforeRenderObservable.add(() => {
    world.update(performance.now());
  });

  const demo = new URLSearchParams(window.location.search).get("demo");
  if (demo !== null) world.runDemo(demo);

  return {
    scene,
    dispose() {
      world.dispose();
      scene.dispose();
    },
  };
}
