import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import type { Mesh } from "@babylonjs/core/Meshes/mesh";
import type { RoomArt } from "@/game/RoomBuilder";

type Baseline = { position: Vector3; rotation: Vector3; scaling: Vector3 };

export class RoomAnimator {
  private readonly art: RoomArt;
  private readonly baselines = new Map<Mesh, Baseline>();

  constructor(art: RoomArt) {
    this.art = art;
    [...art.curtains, ...art.pages, ...art.plants, ...art.castle, ...art.mobile, ...art.lanterns].forEach((mesh) => {
      this.baselines.set(mesh, { position: mesh.position.clone(), rotation: mesh.rotation.clone(), scaling: mesh.scaling.clone() });
    });
  }

  update(now: number) {
    const t = now * .001;
    this.art.curtains.forEach((mesh, index) => this.animate(mesh, index, t, .045, .42, true));
    this.art.pages.forEach((mesh, index) => this.animate(mesh, index + 3, t, .10, 1.75, false));
    this.art.plants.forEach((mesh, index) => this.animate(mesh, index + 8, t, .09, .9, false));
    this.art.castle.forEach((mesh, index) => this.animate(mesh, index + 14, t, .022, .65, false));
    this.art.mobile.forEach((mesh, index) => this.animate(mesh, index + 21, t, .055, .58, true));
    this.art.lanterns.forEach((mesh, index) => {
      const base = this.baselines.get(mesh); if (!base) return;
      const pulse = 1 + Math.sin(t * 2.1 + index) * .028;
      mesh.scaling.copyFromFloats(base.scaling.x * pulse, base.scaling.y * pulse, base.scaling.z * pulse);
    });
  }

  private animate(mesh: Mesh, index: number, time: number, amount: number, speed: number, swayPosition: boolean) {
    const base = this.baselines.get(mesh); if (!base) return;
    const wave = Math.sin(time * speed + index * 1.31);
    mesh.rotation.z = base.rotation.z + wave * amount;
    mesh.rotation.y = base.rotation.y + Math.cos(time * speed * .72 + index) * amount * .36;
    if (swayPosition) mesh.position.x = base.position.x + wave * amount * .85;
  }
}
