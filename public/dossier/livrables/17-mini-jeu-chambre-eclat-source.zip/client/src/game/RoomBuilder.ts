import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { Color3, Color4 } from "@babylonjs/core/Maths/math.color";
import { HemisphericLight, PointLight } from "@babylonjs/core/Lights";
import { GlowLayer } from "@babylonjs/core/Layers/glowLayer";
import { Mesh } from "@babylonjs/core/Meshes";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
import { CSG } from "@babylonjs/core/Meshes/csg";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { Texture } from "@babylonjs/core/Materials/Textures/texture";
import type { Scene } from "@babylonjs/core/scene";
import { assets } from "@/game/assets";

export interface RoomArt {
  ambient: HemisphericLight;
  zoneLights: PointLight[];
  finalLight: PointLight;
  glow: GlowLayer;
  muralPieces: Mesh[];
  floorLights: Mesh[];
  particles: Mesh[];
  curtains: Mesh[];
  pages: Mesh[];
  plants: Mesh[];
  castle: Mesh[];
  mobile: Mesh[];
  lanterns: Mesh[];
}

const c = (hex: string) => Color3.FromHexString(hex);
const palette = {
  cream: "#fff9ef",
  ink: "#3d5657",
  cyan: "#8ecfd6",
  sage: "#889f92",
  coral: "#e87c67",
  apricot: "#ef9b5b",
  blush: "#eda2a2",
  birch: "#e9cfa4",
  white: "#fffdf8",
};

export class RoomBuilder {
  private readonly scene: Scene;
  private readonly materials = new Map<string, StandardMaterial>();
  private readonly curtains: Mesh[] = [];
  private readonly pages: Mesh[] = [];
  private readonly plants: Mesh[] = [];
  private readonly castle: Mesh[] = [];
  private readonly mobile: Mesh[] = [];
  private readonly lanterns: Mesh[] = [];
  private puzzlePrefab: Mesh | null = null;

  constructor(scene: Scene) {
    this.scene = scene;
  }

  build(): RoomArt {
    this.scene.clearColor = new Color4(.96, .95, .90, 1);
    this.scene.ambientColor = c("#fff8ed");
    this.scene.fogMode = 1;
    this.scene.fogColor = c("#fff9ef");
    this.scene.fogDensity = .0038;

    const glow = new GlowLayer("eclatSoftGlow", this.scene, { blurKernelSize: 28 });
    glow.intensity = .15;
    const ambient = new HemisphericLight("eclatDaylight", new Vector3(0, 1, 0), this.scene);
    ambient.diffuse = c("#fff7e7");
    ambient.groundColor = c("#d5e1d4");
    ambient.intensity = .34;
    const finalLight = new PointLight("eclatHeart", new Vector3(0, 4.7, 3.6), this.scene);
    finalLight.diffuse = c(palette.apricot);
    finalLight.range = 18;
    finalLight.intensity = .035;
    const zoneLights = [
      this.makeLight("bedLight", new Vector3(-5.25, 3.2, 1.6), palette.blush),
      this.makeLight("deskLight", new Vector3(4.7, 3.2, 2), palette.apricot),
      this.makeLight("libraryLight", new Vector3(6.4, 4.5, 6.25), palette.sage),
      this.makeLight("rugLight", new Vector3(0, 1.4, 4.7), palette.cyan),
      this.makeLight("artLight", new Vector3(3.85, 6.2, 7.8), palette.coral),
    ];

    this.buildRoomShell();
    this.buildWindowAndCurtains();
    this.buildBed();
    this.buildDeskAndChair();
    this.buildWardrobe();
    this.buildLibrary();
    this.buildToyChestAndDollhouse();
    this.buildReadingCorner();
    this.buildMobile();
    this.buildWallArt();
    const floorLights = this.buildFloorPath();
    const muralPieces = this.buildPuzzlePanel();
    const particles = this.buildParticles();

    return { ambient, zoneLights, finalLight, glow, muralPieces, floorLights, particles, curtains: this.curtains, pages: this.pages, plants: this.plants, castle: this.castle, mobile: this.mobile, lanterns: this.lanterns };
  }

  private buildRoomShell() {
    const floor = this.box("birchFloor", 17.4, .18, 17.2, new Vector3(0, -.1, .5), "floor");
    const floorMat = this.material("floor", "#ebd7b5", "#d7bd92");
    this.texture(floorMat, assets.floorTexture, 4.3, 4.3);
    floor.material = floorMat;

    const wallMat = this.material("porcelainWall", palette.cream, "#e8dccd");
    this.texture(wallMat, assets.wallpaperTexture, 2.35, 1.55);
    this.box("backWall", 17.4, 9.6, .18, new Vector3(0, 4.8, 8.8), "porcelainWall");
    this.box("leftWall", .18, 9.6, 17.4, new Vector3(-8.7, 4.8, .5), "porcelainWall");
    this.box("rightWall", .18, 9.6, 17.4, new Vector3(8.7, 4.8, .5), "porcelainWall");
    this.box("ceiling", 17.4, .1, 17.4, new Vector3(0, 9.55, .5), "ceiling").material = this.material("ceiling", "#fffdf8", "#eff0e6");

    const baseMat = this.material("baseboard", "#f3dbc8", "#dbb89d");
    for (const [x, y, z, w, h, d] of [[0,.3,8.66,17.2,.32,.2],[0,.3,-7.6,17.2,.32,.2],[-8.58,.3,.5,.2,.32,16.1],[8.58,.3,.5,.2,.32,16.1]] as const) {
      this.box("roundedBaseboard", w, h, d, new Vector3(x,y,z), "baseboard").material = baseMat;
    }

    const rug = MeshBuilder.CreateDisc("puzzleRug", { radius: 3.12, tessellation: 72 }, this.scene);
    rug.rotation.x = Math.PI / 2;
    rug.position.set(-.45, .015, 1.9);
    const rugMat = this.material("puzzleRug", palette.cyan, "#6ca9ae");
    this.texture(rugMat, assets.rugTexture, 1.12, 1.12);
    rugMat.specularColor = c("#3e6f74").scale(.2);
    rug.material = rugMat;
    const edge = MeshBuilder.CreateTorus("rugPiping", { diameter: 6.16, thickness: .06, tessellation: 72 }, this.scene);
    edge.rotation.x = Math.PI / 2;
    edge.position.set(-.45,.045,1.9);
    edge.material = this.emissive("rugPiping", palette.blush, palette.coral, .12);
    edge.isPickable = false;

    for (let i=0;i<10;i++) {
      const color = i % 2 ? palette.coral : palette.cyan;
      const inlay = this.puzzlePiece("floorPuzzleInlay", new Vector3(-7.7 + (i * 2.2) % 15.2, .022, -6.9 + (i * 3.9) % 14.2), .14 + (i % 3) * .025, .028, this.emissive(`floorInlayMat${i}`, color, color, .38), new Vector3(Math.PI / 2, 0, (i % 4) * .42));
      inlay.isPickable = false;
    }
  }

  private buildWindowAndCurtains() {
    const sky = this.material("windowSky", "#bfe4e7", "#9acdd0");
    sky.emissiveColor = c("#d8f1ee").scale(.11);
    const pane = this.plane("bigWindow", 3.75, 2.72, new Vector3(-2.28, 6.15, 8.55), sky);
    pane.isPickable = false;
    const frame = this.material("windowFrame", palette.white, "#dec7ac");
    for (const [x,y,z,w,h,d] of [[-2.28,7.55,8.48,4.02,.18,.18],[-2.28,4.78,8.48,4.02,.18,.18],[-4.18,6.15,8.48,.18,2.95,.18],[-.38,6.15,8.48,.18,2.95,.18],[-2.28,6.15,8.48,.12,2.75,.18]] as const) {
      this.box("windowFrame",w,h,d,new Vector3(x,y,z),"windowFrame").material=frame;
    }
    for (let i=0;i<4;i++) {
      const cloud = this.sphere("windowCloud", .34 + (i % 2) * .12, new Vector3(-3.45 + i*.72, 6.83 + (i%2)*.08, 8.39), new Vector3(1.6,.55,.24), this.material("cloud", "#fffdf7", "#e9e5d7"));
      cloud.isPickable=false;
    }
    const curtainMat = this.material("curtain", palette.blush, "#c98282");
    curtainMat.backFaceCulling=false;
    for (const [x, offset] of [[-4.15,-.08],[-.43,.08]] as const) {
      const curtain = this.plane("softCurtain", .92, 3.15, new Vector3(x, 6.05, 8.36 + offset), curtainMat);
      curtain.isPickable=false;
      this.curtains.push(curtain);
    }
    const valance = this.box("curtainRail", 4.08,.14,.16,new Vector3(-2.28,7.72,8.27),"curtainRail");
    valance.material=this.material("curtainRail",palette.apricot,"#be7752");
  }

  private buildBed() {
    const x=-5.25, z=1.45;
    const wood=this.material("bedWood", "#dcae8a", "#bd836e");
    const cyan=this.material("bedCyan", palette.cyan, "#6199a0");
    const blush=this.material("bedBlush", palette.blush, "#bd7777");
    const ivory=this.material("bedIvory", palette.white, "#e7d8c7");
    this.box("bedFrame",4.35,.48,2.62,new Vector3(x,.75,z),"bedWood").material=wood;
    this.box("bedMattress",4.05,.36,2.32,new Vector3(x,1.15,z),"bedIvory").material=ivory;
    this.box("bedDuvet",4.06,.25,1.42,new Vector3(x,1.43,z+.35),"bedCyan").material=cyan;
    this.box("bedDuvetFold",4.08,.14,.42,new Vector3(x,1.59,z-.45),"bedBlush").material=blush;
    this.box("bedHeadboard",4.16,1.72,.2,new Vector3(x,1.78,z+1.22),"bedWood").material=wood;
    this.box("bedFootboard",4.26,.75,.2,new Vector3(x,1.0,z-1.22),"bedWood").material=wood;
    for (const px of [x-1.12,x+1.12]) {
      const pillow=this.sphere("pillow",.63,new Vector3(px,1.53,z+.72),new Vector3(1.23,.42,.78),ivory);
      pillow.isPickable=false;
    }
    for (const px of [x-1.95,x+1.95]) {
      const post=MeshBuilder.CreateCylinder("bedPost",{height:2.65,diameter:.17,tessellation:16},this.scene);
      post.position.set(px,2.02,z+1.1); post.material=wood; post.isPickable=false;
      const cap=this.sphere("bedPostCap",.19,new Vector3(px,3.38,z+1.1),new Vector3(1,1,1),this.emissive("bedCap",palette.apricot,palette.apricot,.24)); cap.isPickable=false;
    }
    const bedside=this.box("bedsideTable",.82,.86,.74,new Vector3(-7.22,.5,1.48),"bedWood"); bedside.material=wood;
    this.box("bedsideDrawer",.62,.22,.06,new Vector3(-7.22,.65,1.09),"bedBlush").material=blush;
    const lampStem=MeshBuilder.CreateCylinder("bedLampStem",{height:.46,diameter:.07,tessellation:12},this.scene); lampStem.position.set(-7.22,1.18,1.48);lampStem.material=wood;lampStem.isPickable=false;
    const lamp=this.sphere("bedLamp",.32,new Vector3(-7.22,1.53,1.48),new Vector3(1,.7,1),this.emissive("bedLampMat",palette.apricot,palette.apricot,.75)); lamp.isPickable=false;this.lanterns.push(lamp);
  }

  private buildDeskAndChair() {
    const wood=this.material("deskWood", "#ddb18e", "#bb826d");
    const coral=this.material("deskCoral", palette.coral, "#ba6656");
    const sage=this.material("deskSage", palette.sage, "#607c6f");
    const cream=this.material("deskCream", palette.white, "#e4d4c3");
    const x=4.65,z=1.78;
    this.box("deskTop",3.35,.20,1.46,new Vector3(x,2.06,z),"deskWood").material=wood;
    this.box("deskCabinet",.88,1.78,1.28,new Vector3(x+1.22,1.03,z+.02),"deskCoral").material=coral;
    for (const dy of [.62,1.12,1.62]) this.box("deskDrawer",.64,.30,.06,new Vector3(x+1.22,dy,z-.65),"deskCream").material=cream;
    for (const px of [x-1.35,x+.35]) for (const pz of [z-.52,z+.52]) {
      const leg=MeshBuilder.CreateCylinder("deskLeg",{height:1.92,diameter:.15,tessellation:14},this.scene);leg.position.set(px,1.0,pz);leg.material=wood;leg.isPickable=false;
    }
    const desktop=this.plane("desktopPaper",1.25,.82,new Vector3(x-.08,2.18,z),cream);desktop.rotation.x=Math.PI/2;desktop.isPickable=false;
    for(let i=0;i<4;i++) { const page=this.plane("turningPage",.75,.46,new Vector3(x-.1+i*.012,2.2+i*.008,z+.03),cream);page.rotation.x=Math.PI/2;page.rotation.z=(i-1.5)*.035;page.isPickable=false;this.pages.push(page); }
    const pot=MeshBuilder.CreateCylinder("pencilPot",{height:.34,diameter:.22,tessellation:12},this.scene);pot.position.set(x-.92,2.27,z+.35);pot.material=sage;pot.isPickable=false;
    for(let i=0;i<4;i++){const pencil=MeshBuilder.CreateCylinder("pencil",{height:.38,diameter:.035,tessellation:8},this.scene);pencil.position.set(x-.96+i*.055,2.5,z+.35);pencil.rotation.z=(i-1.5)*.13;pencil.material=coral;pencil.isPickable=false;}
    const lampStem=MeshBuilder.CreateCylinder("deskLampStem",{height:.75,diameter:.06,tessellation:12},this.scene);lampStem.position.set(x-1.14,2.47,z-.22);lampStem.material=wood;lampStem.isPickable=false;
    const lamp=this.sphere("deskLamp",.31,new Vector3(x-1.14,2.93,z-.22),new Vector3(1.18,.52,1.18),this.emissive("deskLampMat",palette.apricot,palette.apricot,.72));lamp.isPickable=false;this.lanterns.push(lamp);
    const seat=MeshBuilder.CreateCylinder("deskChairSeat",{height:.25,diameter:1.0,tessellation:24},this.scene);seat.position.set(x-.26,.82,z+1.36);seat.material=sage;seat.isPickable=false;
    const back=this.sphere("deskChairBack",.62,new Vector3(x-.26,1.38,z+1.7),new Vector3(1.12,1.25,.28),sage);back.isPickable=false;
    const stem=MeshBuilder.CreateCylinder("deskChairStem",{height:.68,diameter:.10,tessellation:12},this.scene);stem.position.set(x-.26,.42,z+1.36);stem.material=wood;stem.isPickable=false;
    for(const a of [0,Math.PI/2,Math.PI,Math.PI*1.5]){const wheel=this.sphere("chairWheel",.09,new Vector3(x-.26+Math.cos(a)*.42,.08,z+1.36+Math.sin(a)*.42),new Vector3(1,1,.7),wood);wheel.isPickable=false;}
  }

  private buildWardrobe() {
    const x=-6.45,z=6.45;
    const body=this.material("wardrobeBody",palette.sage,"#607d71");
    const door=this.material("wardrobeDoor", "#b7c8bb", "#7f9e8d");
    const knob=this.emissive("wardrobeKnob",palette.apricot,palette.apricot,.22);
    this.box("wardrobeBody",2.66,5.7,1.45,new Vector3(x,2.95,z),"wardrobeBody").material=body;
    this.box("wardrobeTop",2.86,.24,1.65,new Vector3(x,5.93,z),"wardrobeBody").material=body;
    for(const px of [x-.64,x+.64]) {this.box("wardrobeDoor",1.16,4.86,.12,new Vector3(px,3.25,z-.76),"wardrobeDoor").material=door;const handle=this.sphere("wardrobeHandle",.105,new Vector3(px+(px<x?-.15:.15),3.25,z-.85),new Vector3(1,1,.5),knob);handle.isPickable=false;}
    const box=this.box("wardrobeStorageBox",1.35,.45,.92,new Vector3(x,6.3,z),"deskCoral");box.material=this.material("wardrobeBox",palette.coral,"#bb6554");
  }

  private buildLibrary() {
    const x=6.55,z=6.7;
    const wood=this.material("shelfWood", "#d9b08d", "#b9826c");
    const cyan=this.material("shelfCyan", palette.cyan, "#649ca2");
    const sage=this.material("shelfSage", palette.sage, "#607d70");
    const coral=this.material("shelfCoral", palette.coral, "#b96354");
    this.box("bookcaseBody",2.75,5.75,.72,new Vector3(x,3.08,z),"shelfWood").material=wood;
    for(const px of [x-1.25,x+1.25]) this.box("bookcaseSide",.16,5.85,.88,new Vector3(px,3.08,z),"shelfWood").material=wood;
    for(const y of [.55,1.98,3.42,4.86,5.86]) this.box("bookcaseShelf",2.55,.14,.84,new Vector3(x,y,z),"shelfWood").material=wood;
    const bookMats=[cyan,sage,coral,this.material("shelfApricot",palette.apricot,"#bc7b4b")];
    [[5.66,1.12],[5.95,1.12],[6.25,1.12],[6.58,2.55],[6.9,2.55],[7.22,4.0],[7.52,4.0],[6.1,5.37]].forEach(([px,py],i)=>{const book=this.box("shelfBook",.21,.66+(i%3)*.12,.42,new Vector3(px,py,z-.28),"shelfBook");book.material=bookMats[i%bookMats.length];});
    const pot=MeshBuilder.CreateCylinder("shelfPot",{height:.38,diameter:.56,tessellation:16},this.scene);pot.position.set(5.95,4.94,z-.2);pot.material=coral;pot.isPickable=false;
    for(let i=0;i<7;i++){const leaf=this.sphere("shelfLeaf",.26,new Vector3(5.95+Math.sin(i*.9)*.32,5.22+(i%3)*.14,z-.18+Math.cos(i*.6)*.11),new Vector3(.7,1.7,.42),sage);leaf.isPickable=false;this.plants.push(leaf);}
    const jar=this.sphere("shelfJar",.34,new Vector3(7.35,5.28,z-.27),new Vector3(1,1,1),this.emissive("shelfJarMat",palette.cyan,palette.cyan,.46));jar.isPickable=false;this.lanterns.push(jar);
  }

  private buildToyChestAndDollhouse() {
    const chest=this.material("toyChest",palette.cyan,"#649aa0");
    const lid=this.material("toyChestLid",palette.apricot,"#bb7750");
    this.box("toyChestBody",2.4,1.25,1.15,new Vector3(.8,.67,5.45),"toyChest").material=chest;
    this.box("toyChestLid",2.5,.22,1.25,new Vector3(.8,1.4,5.45),"toyChestLid").material=lid;
    const handle=this.sphere("toyChestHandle",.16,new Vector3(.8,1.55,4.82),new Vector3(1.9,.5,.4),this.material("toyChestHandle",palette.cream,"#d7c9bb"));handle.isPickable=false;
    const ball=this.sphere("toyBall",.44,new Vector3(2.26,.43,5.02),new Vector3(1,1,1),this.material("toyBall",palette.coral,"#b96255"));ball.isPickable=false;

    const base=this.box("dollhouseBase",2.4,.28,1.0,new Vector3(-3.35,1.53,5.8),"dollhouseBase");base.material=this.material("dollhouseBase",palette.sage,"#607d70");this.castle.push(base);
    for(const [px,height,material] of [[-4.08,1.5,palette.cyan],[-3.35,2.05,palette.blush],[-2.63,1.62,palette.apricot]] as const){const house=MeshBuilder.CreateBox("dollhouseTower",{width:.58,height,depth:.66},this.scene);house.position.set(px,1.67+height/2,5.8);house.material=this.material(`house${px}`,material,"#9b8d7a");house.isPickable=false;this.castle.push(house);const roof=MeshBuilder.CreateCylinder("dollhouseRoof",{height:.48,diameterTop:0,diameterBottom:.84,tessellation:4},this.scene);roof.position.set(px,1.67+height+.24,5.8);roof.rotation.y=Math.PI/4;roof.material=this.material(`roof${px}`,palette.coral,"#b96255");roof.isPickable=false;this.castle.push(roof);}
    const door=this.box("dollhouseDoor",.28,.52,.05,new Vector3(-3.35,1.96,5.44),"dollhouseDoor");door.material=this.emissive("dollhouseDoor",palette.cream,palette.apricot,.25);this.castle.push(door);
  }

  private buildReadingCorner() {
    const velvet=this.material("readingBlush",palette.blush,"#bc7879");
    const wood=this.material("readingWood","#d9ad8a","#b87e68");
    const chairBase=this.sphere("readingChairSeat",.78,new Vector3(2.5,.62,6.2),new Vector3(1.15,.52,.92),velvet);chairBase.isPickable=false;
    const chairBack=this.sphere("readingChairBack",.94,new Vector3(2.5,1.35,6.62),new Vector3(1.12,1.2,.42),velvet);chairBack.isPickable=false;
    const table=this.box("readingTable",.86,.12,.86,new Vector3(1.1,1.05,6.1),"readingWood");table.material=wood;
    const leg=MeshBuilder.CreateCylinder("readingTableLeg",{height:1.02,diameter:.11,tessellation:12},this.scene);leg.position.set(1.1,.5,6.1);leg.material=wood;leg.isPickable=false;
    const lampStem=MeshBuilder.CreateCylinder("readingLampStem",{height:1.15,diameter:.07,tessellation:12},this.scene);lampStem.position.set(1.1,1.62,6.1);lampStem.material=wood;lampStem.isPickable=false;
    const lamp=this.sphere("readingLamp",.29,new Vector3(1.1,2.3,6.1),new Vector3(1.2,.58,1.2),this.emissive("readingLampMat",palette.apricot,palette.apricot,.66));lamp.isPickable=false;this.lanterns.push(lamp);
    const book=this.box("readingBook",.55,.09,.4,new Vector3(1.1,1.17,6.1),"readingBook");book.material=this.material("readingBook",palette.coral,"#b96255");
  }

  private buildMobile() {
    const thread=this.material("mobileThread",palette.sage,"#6d887b");
    const ring=MeshBuilder.CreateTorus("mobileRing",{diameter:1.7,thickness:.045,tessellation:36},this.scene);ring.position.set(.3,8.12,-.3);ring.rotation.x=Math.PI/2;ring.material=this.emissive("mobileRingMat",palette.apricot,palette.apricot,.38);ring.isPickable=false;this.mobile.push(ring);
    const ornaments=[[-.36,6.75,-.3,.20,palette.cyan],[.32,6.35,-.08,.25,palette.coral],[.92,6.86,-.38,.18,palette.sage]] as const;
    ornaments.forEach(([x,y,z,size,color],i)=>{const line=MeshBuilder.CreateCylinder("mobileString",{height:8.12-y,diameter:.018,tessellation:8},this.scene);line.position.set(x,(8.12+y)/2,z);line.material=thread;line.isPickable=false;const ornament=this.puzzlePiece(`mobilePuzzle${i}`,new Vector3(x,y,z),size*3.2,.065,this.emissive(`mobileMat${i}`,color,color,.58),new Vector3(0,0,(i-1)*.36));ornament.isPickable=false;this.mobile.push(ornament);});
  }

  private buildWallArt() {
    const artMat=new StandardMaterial("puzzleArtMat",this.scene);
    const texture=new Texture(assets.wallArtTexture,this.scene);texture.hasAlpha=false;artMat.diffuseTexture=texture;artMat.specularColor=Color3.Black();artMat.emissiveColor=Color3.White().scale(.025);artMat.backFaceCulling=false;
    const art=this.plane("puzzleWallArtwork",3.55,2.66,new Vector3(4.18,6.03,8.55),artMat);art.isPickable=false;
    const frame=this.material("artFrame","#e5c59d","#c99c75");
    for(const [x,y,w,h] of [[4.18,7.42,3.85,.12],[4.18,4.64,3.85,.12],[2.27,6.03,.12,2.88],[6.09,6.03,.12,2.88]] as const){this.box("artFrame",w,h,.12,new Vector3(x,y,8.43),"artFrame").material=frame;}
  }

  private buildPuzzlePanel() {
    const pieces: Mesh[]=[];
    const colors=[palette.cyan,palette.sage,palette.coral,palette.apricot];
    const positions=[[-1.1,6.68],[.35,6.68],[-1.1,5.22],[.35,5.22]] as const;
    positions.forEach(([x,y],i)=>{const piece=this.puzzlePiece(`puzzlePanelPiece${i}`,new Vector3(x,y,8.36),1.12,.12,this.emissive(`puzzlePiece${i}`,colors[i],colors[i],.20),new Vector3(0,0,(i%2?1:-1)*.08));piece.visibility=.55;piece.isPickable=false;pieces.push(piece);});
    return pieces;
  }

  private buildFloorPath() {
    const stars:Mesh[]=[];
    const colors=[palette.cyan,palette.sage,palette.coral,palette.apricot,palette.blush];
    for(let i=0;i<17;i++){const marker=this.puzzlePiece("floorPathPuzzle",new Vector3(-.4+Math.sin(i*.76)*.72,.05,-.9+i*.38),.11+(i%3)*.025,.032,this.emissive(`pathMat${i}`,colors[i%colors.length],colors[i%colors.length],.54),new Vector3(Math.PI/2,0,i*.32));marker.visibility=.20;marker.isPickable=false;stars.push(marker);}return stars;
  }

  private buildParticles() {
    const particles:Mesh[]=[];
    const colors=[palette.cyan,palette.sage,palette.coral,palette.apricot];
    for(let i=0;i<62;i++){const particle=this.sphere("softParticle",.022+(i%3)*.009,new Vector3(-7.4+((i*1.73)%14.8),.7+((i*1.11)%7.8),-5.8+((i*2.23)%13.6)),new Vector3(1,1,1),this.emissive(`particleMat${i%4}`,colors[i%4],colors[i%4],.48));particle.visibility=.035;particle.isPickable=false;particles.push(particle);}return particles;
  }

  private makeLight(name:string,position:Vector3,hex:string) { const light=new PointLight(name,position,this.scene);light.diffuse=c(hex);light.range=6.4;light.intensity=.055;return light; }
  private material(name:string,diffuse:string,specular:string) { const existing=this.materials.get(name);if(existing)return existing;const material=new StandardMaterial(name,this.scene);material.diffuseColor=c(diffuse);material.emissiveColor=c(diffuse).scale(.02);material.specularColor=c(specular).scale(.2);material.roughness=.8;this.materials.set(name,material);return material; }
  private emissive(name:string,diffuse:string,emissive:string,intensity:number) { const material=this.material(name,diffuse,"#000000");material.emissiveColor=c(emissive).scale(intensity);return material; }
  private texture(material:StandardMaterial,url:string,u:number,v:number) { const texture=new Texture(url,this.scene);texture.uScale=u;texture.vScale=v;material.diffuseTexture=texture;material.specularColor=Color3.Black(); }
  private puzzlePiece(name:string,position:Vector3,scale:number,thickness:number,material:StandardMaterial,rotation=new Vector3(0,0,0)) {
    const mesh=this.getPuzzlePrefab().clone(name);
    if (!mesh) throw new Error("Puzzle piece clone could not be created");
    mesh.setEnabled(true); mesh.position.copyFrom(position); mesh.rotation.copyFrom(rotation); mesh.scaling.copyFromFloats(scale,scale,thickness/.16); mesh.material=material; mesh.isPickable=false;
    return mesh;
  }
  private getPuzzlePrefab() {
    if (this.puzzlePrefab) return this.puzzlePrefab;
    const material=this.material("puzzlePrefabMat",palette.cream,"#e4d4c1");
    const base=MeshBuilder.CreateBox("puzzlePieceBase",{width:1,height:1,depth:.16},this.scene); base.material=material;
    const rightTab=MeshBuilder.CreateCylinder("puzzlePieceRightTab",{height:.16,diameter:.38,tessellation:24},this.scene); rightTab.rotation.x=Math.PI/2; rightTab.position.set(.50,.20,0); rightTab.material=material;
    const topTab=MeshBuilder.CreateCylinder("puzzlePieceTopTab",{height:.16,diameter:.38,tessellation:24},this.scene); topTab.rotation.x=Math.PI/2; topTab.position.set(-.20,.50,0); topTab.material=material;
    const leftSocket=MeshBuilder.CreateCylinder("puzzlePieceLeftSocket",{height:.22,diameter:.38,tessellation:24},this.scene); leftSocket.rotation.x=Math.PI/2; leftSocket.position.set(-.50,-.20,0); leftSocket.material=material;
    const bottomSocket=MeshBuilder.CreateCylinder("puzzlePieceBottomSocket",{height:.22,diameter:.38,tessellation:24},this.scene); bottomSocket.rotation.x=Math.PI/2; bottomSocket.position.set(.20,-.50,0); bottomSocket.material=material;
    const shape=CSG.FromMesh(base).union(CSG.FromMesh(rightTab)).union(CSG.FromMesh(topTab)).subtract(CSG.FromMesh(leftSocket)).subtract(CSG.FromMesh(bottomSocket));
    const prefab=shape.toMesh("puzzlePiecePrefab",material,this.scene);
    [base,rightTab,topTab,leftSocket,bottomSocket].forEach((mesh)=>mesh.dispose());
    prefab.setEnabled(false); prefab.isPickable=false; this.puzzlePrefab=prefab; return prefab;
  }
  private box(name:string,width:number,height:number,depth:number,position:Vector3,materialName:string) { const mesh=MeshBuilder.CreateBox(name,{width,height,depth},this.scene);mesh.position.copyFrom(position);mesh.material=this.materials.get(materialName)??this.material(materialName,palette.cream,"#e7d8c7");mesh.isPickable=false;return mesh; }
  private sphere(name:string,diameter:number,position:Vector3,scaling:Vector3,material:StandardMaterial) { const mesh=MeshBuilder.CreateSphere(name,{diameter,segments:16},this.scene);mesh.position.copyFrom(position);mesh.scaling.copyFrom(scaling);mesh.material=material;return mesh; }
  private plane(name:string,width:number,height:number,position:Vector3,material:StandardMaterial) { const mesh=MeshBuilder.CreatePlane(name,{width,height,sideOrientation:Mesh.DOUBLESIDE},this.scene);mesh.position.copyFrom(position);mesh.material=material;return mesh; }
}
