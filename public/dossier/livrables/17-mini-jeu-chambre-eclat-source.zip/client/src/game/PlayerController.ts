import { UniversalCamera } from "@babylonjs/core/Cameras/universalCamera";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import type { Scene } from "@babylonjs/core/scene";

type TouchAxis = { forward: number; right: number };

export class PlayerController {
  readonly camera: UniversalCamera;
  private readonly canvas: HTMLCanvasElement;
  private enabled = false;
  private touchStart: { x: number; y: number } | null = null;
  private readonly pressed = new Set<string>();
  private touchAxis: TouchAxis = { forward: 0, right: 0 };
  private readonly cleanups: Array<() => void> = [];

  constructor(scene: Scene, canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.camera = new UniversalCamera("playerCamera", new Vector3(0, 1.75, -7.2), scene);
    this.camera.minZ = 0.08;
    this.camera.speed = 0;
    this.camera.inertia = 0.52;
    this.camera.angularSensibility = 3600;
    this.camera.keysUp = [];
    this.camera.keysDown = [];
    this.camera.keysLeft = [];
    this.camera.keysRight = [];
    this.camera.attachControl(canvas, true);
    this.camera.inputs.removeByType("FreeCameraMouseInput");

    const movementKeys = new Set(["w", "a", "s", "d", "z", "q", "arrowup", "arrowdown", "arrowleft", "arrowright"]);
    const onKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (!this.enabled || !movementKeys.has(key)) return;
      this.pressed.add(key);
      event.preventDefault();
    };
    const onKeyUp = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (!movementKeys.has(key)) return;
      this.pressed.delete(key);
      event.preventDefault();
    };
    const onMouseMove = (event: MouseEvent) => {
      if (!this.enabled || document.pointerLockElement !== canvas) return;
      this.camera.rotation.y += event.movementX / 2400;
      this.camera.rotation.x += event.movementY / 2400;
      this.clampRotation();
    };
    const onTouchStart = (event: TouchEvent) => {
      if (!this.enabled || event.touches.length !== 1) return;
      const touch = event.touches[0];
      this.touchStart = { x: touch.clientX, y: touch.clientY };
    };
    const onTouchMove = (event: TouchEvent) => {
      if (!this.enabled || !this.touchStart || event.touches.length !== 1) return;
      const touch = event.touches[0];
      this.camera.rotation.y += (touch.clientX - this.touchStart.x) / 300;
      this.camera.rotation.x += (touch.clientY - this.touchStart.y) / 300;
      this.touchStart = { x: touch.clientX, y: touch.clientY };
      this.clampRotation();
    };
    const onTouchEnd = () => { this.touchStart = null; };
    const onBlur = () => this.stopMovement();
    const onContext = (event: Event) => event.preventDefault();

    window.addEventListener("keydown", onKeyDown, { passive: false });
    window.addEventListener("keyup", onKeyUp, { passive: false });
    window.addEventListener("blur", onBlur);
    window.addEventListener("mousemove", onMouseMove);
    canvas.addEventListener("touchstart", onTouchStart, { passive: true });
    canvas.addEventListener("touchmove", onTouchMove, { passive: true });
    canvas.addEventListener("touchend", onTouchEnd, { passive: true });
    canvas.addEventListener("contextmenu", onContext);
    this.cleanups.push(
      () => window.removeEventListener("keydown", onKeyDown),
      () => window.removeEventListener("keyup", onKeyUp),
      () => window.removeEventListener("blur", onBlur),
      () => window.removeEventListener("mousemove", onMouseMove),
      () => canvas.removeEventListener("touchstart", onTouchStart),
      () => canvas.removeEventListener("touchmove", onTouchMove),
      () => canvas.removeEventListener("touchend", onTouchEnd),
      () => canvas.removeEventListener("contextmenu", onContext),
    );
  }

  start(requestPointerLock: boolean) {
    this.enabled = true;
    this.canvas.focus();
    if (requestPointerLock && this.canvas.requestPointerLock) {
      this.canvas.requestPointerLock().catch(() => undefined);
    }
  }

  setTouchAxis(axis: TouchAxis) {
    this.touchAxis = axis;
  }

  reset() {
    this.camera.position.copyFromFloats(0, 1.75, -7.2);
    this.camera.rotation.copyFromFloats(0, 0, 0);
    this.stopMovement();
  }

  update(deltaSeconds: number) {
    if (!this.enabled) return;
    const forwardInput = (this.pressed.has("w") || this.pressed.has("z") || this.pressed.has("arrowup") ? 1 : 0)
      - (this.pressed.has("s") || this.pressed.has("arrowdown") ? 1 : 0)
      + this.touchAxis.forward;
    const sideInput = (this.pressed.has("d") || this.pressed.has("arrowright") ? 1 : 0)
      - (this.pressed.has("a") || this.pressed.has("q") || this.pressed.has("arrowleft") ? 1 : 0)
      + this.touchAxis.right;

    if (forwardInput || sideInput) {
      const forward = new Vector3(Math.sin(this.camera.rotation.y), 0, Math.cos(this.camera.rotation.y));
      const right = new Vector3(forward.z, 0, -forward.x);
      const movement = forward.scale(forwardInput).add(right.scale(sideInput));
      if (movement.lengthSquared() > 0) {
        movement.normalize().scaleInPlace(Math.min(deltaSeconds, .05) * 3.6);
        this.camera.position.addInPlace(movement);
      }
    }
    this.camera.position.x = Math.max(-7.55, Math.min(7.55, this.camera.position.x));
    this.camera.position.z = Math.max(-7.7, Math.min(8.1, this.camera.position.z));
    this.camera.position.y = 1.75;
    this.clampRotation();
  }

  dispose() {
    this.cleanups.forEach((cleanup) => cleanup());
    this.camera.detachControl();
  }

  private stopMovement() {
    this.pressed.clear();
    this.touchAxis = { forward: 0, right: 0 };
  }

  private clampRotation() {
    this.camera.rotation.x = Math.max(-1.18, Math.min(1.12, this.camera.rotation.x));
  }
}
