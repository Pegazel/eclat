import type { RoomArt } from "@/game/RoomBuilder";

const clamp01 = (value: number) => Math.max(0, Math.min(1, value));

export class IlluminationController {
  private readonly art: RoomArt;
  private fragmentCount = 0;
  private finalStartedAt: number | null = null;
  private finished = false;

  constructor(art: RoomArt) {
    this.art = art;
  }

  onFragment(count: number) {
    this.fragmentCount = count;
    const warmth = count / 5;
    this.art.ambient.intensity = .39 + warmth * .32;
    this.art.finalLight.intensity = .08 + warmth * .42;
    this.art.zoneLights.slice(0, count).forEach((light, index) => {
      light.intensity = .13 + index * .075;
    });
    this.art.floorLights.forEach((star, index) => {
      if (index < count * 4) star.visibility = .32 + warmth * .48;
    });
    this.art.muralPieces.slice(0, Math.min(count * 2, this.art.muralPieces.length)).forEach((piece) => {
      piece.visibility = .28 + warmth * .55;
    });
  }

  beginFinal(now: number) {
    this.finalStartedAt = now;
  }

  update(now: number) {
    if (this.finalStartedAt === null) return false;
    const elapsed = (now - this.finalStartedAt) / 1000;
    const wave = clamp01(elapsed / 4.7);
    const ease = 1 - Math.pow(1 - wave, 3);
    this.art.ambient.intensity = .71 + ease * .20;
    this.art.finalLight.intensity = .50 + ease * 1.02;
    this.art.glow.intensity = .22 + ease * .86;
    this.art.zoneLights.forEach((light, index) => {
      const stagger = clamp01((elapsed - index * .32) / 2.0);
      light.intensity = .22 + (1 - Math.pow(1 - stagger, 3)) * .86;
    });
    this.art.floorLights.forEach((star, index) => {
      const reveal = clamp01((elapsed - index * .055) / 1.5);
      star.visibility = .3 + reveal * .7;
    });
    this.art.muralPieces.forEach((piece, index) => {
      const reveal = clamp01((elapsed - 1.25 - index * .12) / 1.5);
      piece.visibility = .35 + reveal * .65;
    });
    this.art.particles.forEach((particle, index) => {
      const reveal = clamp01((elapsed - 1.1 - (index % 16) * .07) / 1.4);
      particle.visibility = .1 + reveal * .78;
      particle.position.y += Math.sin(now * .0012 + index) * .0014;
    });
    if (elapsed >= 6.0 && !this.finished) { this.finished = true; return true; }
    return false;
  }

  forceComplete() {
    this.fragmentCount = 5;
    this.art.ambient.intensity = .91;
    this.art.finalLight.intensity = 1.52;
    this.art.glow.intensity = 1.18;
    this.art.zoneLights.forEach((light) => (light.intensity = 1.04));
    this.art.floorLights.forEach((star) => (star.visibility = 1));
    this.art.muralPieces.forEach((piece) => (piece.visibility = 1));
    this.art.particles.forEach((particle) => (particle.visibility = .78));
    this.finished = true;
  }
}
