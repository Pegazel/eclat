import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { Color3 } from "@babylonjs/core/Maths/math.color";
import { Mesh, TransformNode } from "@babylonjs/core/Meshes";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { Texture } from "@babylonjs/core/Materials/Textures/texture";
import "@babylonjs/core/Culling/ray";
import type { Scene } from "@babylonjs/core/scene";
import type { UniversalCamera } from "@babylonjs/core/Cameras/universalCamera";
import type { FragmentDefinition } from "@/game/types";
import { assets } from "@/game/assets";

interface FragmentInstance {
  definition: FragmentDefinition;
  root: TransformNode;
  meshes: Mesh[];
  baseY: number;
  collected: boolean;
}

const fragments: FragmentDefinition[] = [
  { id: 1, label: "LE LIT", message: "Le porte-clés cyan réveille le coin dodo.", position: [-5.12, 2.42, 1.78], color: [0.56, 0.81, 0.84] },
  { id: 2, label: "LE BUREAU", message: "Le porte-clés corail fait danser les couleurs.", position: [4.42, 2.92, 1.66], color: [0.91, 0.49, 0.40] },
  { id: 3, label: "LA BIBLIOTHÈQUE", message: "Le porte-clés sauge éclaire les histoires.", position: [6.42, 4.4, 6.06], color: [0.53, 0.62, 0.57] },
  { id: 4, label: "LE TAPIS", message: "Le porte-clés abricot assemble le chemin.", position: [-0.28, 0.92, 4.45], color: [0.94, 0.61, 0.36] },
  { id: 5, label: "LE TABLEAU", message: "Le dernier porte-clés illumine toute la chambre.", position: [4.18, 6.05, 8.18], color: [0.93, 0.64, 0.64], locked: true },
];

export class FragmentManager {
  private readonly scene: Scene;
  private readonly items: FragmentInstance[];

  constructor(scene: Scene) {
    this.scene = scene;
    this.items = fragments.map((definition) => this.makeFragment(definition));
    this.items.find((item) => item.definition.locked)?.root.setEnabled(false);
  }

  update(camera: UniversalCamera, time: number) {
    for (const item of this.items) {
      if (item.collected || !item.root.isEnabled()) continue;
      const pulse = Math.sin(time * 2.3 + item.definition.id) * .5 + .5;
      item.root.position.y = item.baseY + Math.sin(time * 1.7 + item.definition.id) * .09;
      item.root.rotation.z = Math.sin(time * 1.35 + item.definition.id) * .045;
      item.root.scaling.setAll(1 + pulse * .045);
      item.meshes[0].visibility = .85 + pulse * .15;
      item.meshes[1].visibility = .13 + pulse * .12;
    }
    return this.getNearest(camera) !== null;
  }

  tryCollectFromCamera(camera: UniversalCamera) {
    const picked = this.scene.pickWithRay(camera.getForwardRay(8), (mesh) => typeof mesh.metadata?.fragmentId === "number");
    const id = picked?.pickedMesh?.metadata?.fragmentId as number | undefined;
    if (id) return this.collect(id);
    const nearest = this.getNearest(camera, 3.3, .72);
    return nearest ? this.collect(nearest.definition.id) : null;
  }

  collectById(id: number) {
    return this.collect(id);
  }

  get count() {
    return this.items.filter((item) => item.collected).length;
  }

  private collect(id: number) {
    const item = this.items.find((candidate) => candidate.definition.id === id);
    if (!item || item.collected || !item.root.isEnabled()) return null;
    if (item.definition.locked && this.count < 4) return null;
    item.collected = true;
    item.root.setEnabled(false);
    if (this.count === 4) {
      const final = this.items.find((candidate) => candidate.definition.id === 5);
      final?.root.setEnabled(true);
    }
    return item.definition;
  }

  private getNearest(camera: UniversalCamera, maxDistance = 3.5, minFacing = .67) {
    let nearest: FragmentInstance | null = null;
    let distance = Infinity;
    const forward = camera.getForwardRay().direction.normalize();
    for (const item of this.items) {
      if (item.collected || !item.root.isEnabled()) continue;
      const delta = item.root.getAbsolutePosition().subtract(camera.position);
      const d = delta.length();
      if (d > maxDistance || Vector3.Dot(forward, delta.normalize()) < minFacing) continue;
      if (d < distance) { nearest = item; distance = d; }
    }
    return nearest;
  }

  private makeFragment(definition: FragmentDefinition): FragmentInstance {
    const root = new TransformNode(`keychainRoot${definition.id}`, this.scene);
    root.position.set(...definition.position);
    const color = new Color3(...definition.color);

    const auraMaterial = new StandardMaterial(`keychainAuraMat${definition.id}`, this.scene);
    auraMaterial.diffuseColor = color;
    auraMaterial.emissiveColor = color.scale(.75);
    auraMaterial.alpha = .18;
    auraMaterial.backFaceCulling = false;

    const aura = MeshBuilder.CreateDisc(`keychainAura${definition.id}`, { radius: .88, tessellation: 36 }, this.scene);
    aura.parent = root;
    aura.position.z = .045;
    aura.billboardMode = Mesh.BILLBOARDMODE_ALL;
    aura.material = auraMaterial;
    aura.isPickable = false;

    const texture = new Texture(assets.keychainTextures[definition.id - 1], this.scene);
    texture.hasAlpha = true;
    const keychainMaterial = new StandardMaterial(`keychainMat${definition.id}`, this.scene);
    keychainMaterial.diffuseTexture = texture;
    keychainMaterial.emissiveTexture = texture;
    keychainMaterial.opacityTexture = texture;
    keychainMaterial.useAlphaFromDiffuseTexture = true;
    keychainMaterial.emissiveColor = Color3.White();
    keychainMaterial.specularColor = Color3.White();
    keychainMaterial.backFaceCulling = false;

    const keychain = MeshBuilder.CreatePlane(`keychainCollectible${definition.id}`, { width: 1.35, height: 1.82 }, this.scene);
    keychain.parent = root;
    keychain.position.z = -.12;
    keychain.billboardMode = Mesh.BILLBOARDMODE_ALL;
    keychain.material = keychainMaterial;
    keychain.metadata = { fragmentId: definition.id };

    const halo = MeshBuilder.CreateTorus(`keychainHalo${definition.id}`, { diameter: 1.55, thickness: .025, tessellation: 36 }, this.scene);
    halo.parent = root;
    halo.position.z = .06;
    halo.billboardMode = Mesh.BILLBOARDMODE_ALL;
    const haloMaterial = new StandardMaterial(`keychainHaloMat${definition.id}`, this.scene);
    haloMaterial.emissiveColor = color.scale(.85);
    haloMaterial.alpha = .5;
    haloMaterial.backFaceCulling = false;
    halo.material = haloMaterial;
    halo.isPickable = false;

    // A small 3D silhouette keeps the collectible legible before the texture finishes streaming.
    const proxyMaterial = new StandardMaterial(`keychainProxyMat${definition.id}`, this.scene);
    proxyMaterial.diffuseColor = color.scale(.72);
    proxyMaterial.emissiveColor = color.scale(.38);
    proxyMaterial.specularColor = Color3.White();
    const ring = MeshBuilder.CreateTorus(`keychainRing${definition.id}`, { diameter: .4, thickness: .045, tessellation: 20 }, this.scene);
    ring.parent = root; ring.position.set(0, .53, .015); ring.material = haloMaterial; ring.isPickable = false;
    const chain = MeshBuilder.CreateCylinder(`keychainChain${definition.id}`, { height: .34, diameter: .035, tessellation: 8 }, this.scene);
    chain.parent = root; chain.position.set(0, .30, .015); chain.material = haloMaterial; chain.isPickable = false;
    const pieceA = MeshBuilder.CreateBox(`keychainPieceA${definition.id}`, { width: .38, height: .36, depth: .1 }, this.scene);
    pieceA.parent = root; pieceA.position.set(-.18, -.12, .01); pieceA.material = proxyMaterial; pieceA.isPickable = false;
    const pieceB = MeshBuilder.CreateBox(`keychainPieceB${definition.id}`, { width: .38, height: .36, depth: .1 }, this.scene);
    pieceB.parent = root; pieceB.position.set(.18, -.12, .01); pieceB.material = proxyMaterial; pieceB.isPickable = false;
    const tab = MeshBuilder.CreateSphere(`keychainTab${definition.id}`, { diameter: .16, segments: 10 }, this.scene);
    tab.parent = root; tab.position.set(0, -.12, .01); tab.material = haloMaterial; tab.isPickable = false;

    return { definition, root, meshes: [keychain, aura, halo, ring, chain, pieceA, pieceB, tab], baseY: definition.position[1], collected: false };
  }
}
