export class AudioManager {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;
  private drone: OscillatorNode | null = null;
  private shimmerTimer: number | null = null;
  private muted = false;
  private volume = .72;

  start() {
    if (typeof window === "undefined") return;
    if (!this.context) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;
      this.context = new AudioContextClass();
      this.master = this.context.createGain();
      this.master.connect(this.context.destination);
      this.applyLevel();
      this.startAmbience();
    }
    void this.context.resume();
  }

  setSettings({ muted, volume }: { muted?: boolean; volume?: number }) {
    if (typeof muted === "boolean") this.muted = muted;
    if (typeof volume === "number") this.volume = Math.max(0, Math.min(1, volume));
    this.applyLevel();
  }

  fragment(index: number) {
    if (!this.context || !this.master || this.muted) return;
    const notes = [523.25, 587.33, 659.25, 783.99, 880];
    const root = notes[(index - 1) % notes.length];
    this.tone(root * .5, .7, .05, "sine", 0);
    this.tone(root, 1.1, .085, "sine", .06);
    this.tone(root * 1.5, 1.3, .052, "triangle", .13);
  }

  finale() {
    if (!this.context || !this.master || this.muted) return;
    [261.63, 329.63, 392, 523.25].forEach((frequency, index) => this.tone(frequency, 3.4, .07, "sine", index * .12));
    [659.25, 783.99, 1046.5].forEach((frequency, index) => this.tone(frequency, 1.8, .055, "triangle", .56 + index * .13));
  }

  dispose() {
    if (this.shimmerTimer !== null) window.clearInterval(this.shimmerTimer);
    this.drone?.stop();
    this.context?.close().catch(() => undefined);
    this.context = null;
    this.master = null;
  }

  private applyLevel() {
    if (!this.context || !this.master) return;
    this.master.gain.setTargetAtTime(this.muted ? 0 : .18 * this.volume, this.context.currentTime, .08);
  }

  private startAmbience() {
    if (!this.context || !this.master) return;
    const droneGain = this.context.createGain();
    droneGain.gain.value = .028;
    droneGain.connect(this.master);
    this.drone = this.context.createOscillator();
    this.drone.type = "sine";
    this.drone.frequency.value = 130.81;
    this.drone.detune.value = -8;
    this.drone.connect(droneGain);
    this.drone.start();
    this.shimmerTimer = window.setInterval(() => {
      const scale = [392, 440, 523.25, 587.33, 659.25];
      this.tone(scale[Math.floor(Math.random() * scale.length)], 1.7, .018, "sine", 0);
    }, 3800);
  }

  private tone(frequency: number, duration: number, volume: number, type: OscillatorType, delay: number) {
    if (!this.context || !this.master || this.muted) return;
    const now = this.context.currentTime + delay;
    const gain = this.context.createGain();
    const oscillator = this.context.createOscillator();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, now);
    gain.gain.setValueAtTime(.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + .03);
    gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
    oscillator.connect(gain);
    gain.connect(this.master);
    oscillator.start(now);
    oscillator.stop(now + duration + .06);
  }
}

declare global { interface Window { webkitAudioContext?: typeof AudioContext; } }
