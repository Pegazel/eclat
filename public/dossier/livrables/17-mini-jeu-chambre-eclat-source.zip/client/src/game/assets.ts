export const assets = {
  wallpaperTexture: "/manus-storage/eclat-puzzle-wallpaper-v2-mobile_77f30ec3.png",
  floorTexture: "/manus-storage/eclat-light-wood-floor-mobile_4e3159c5.png",
  rugTexture: "/manus-storage/eclat-puzzle-rug-mobile_608700f2.png",
  wallArtTexture: "/manus-storage/eclat-puzzle-wall-art-v2-mobile_b5bbb781.png",
  keychainTextures: [
    "/manus-storage/keychain-fragment-lilac-sprite_4237ee67.png",
    "/manus-storage/keychain-fragment-amber-sprite_a078a84f.png",
    "/manus-storage/keychain-fragment-mint-sprite_5570b9e9.png",
    "/manus-storage/keychain-fragment-blue-sprite_d65f1fee.png",
    "/manus-storage/keychain-fragment-gold-sprite_d86f898b.png",
  ],
} as const;
