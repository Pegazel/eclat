import type { Scene } from "@babylonjs/core/scene";
import type { GamePhase, GameSnapshot } from "@/game/types";
import { PlayerController } from "@/game/PlayerController";
import { RoomBuilder } from "@/game/RoomBuilder";
import { RoomAnimator } from "@/game/RoomAnimator";
import { FragmentManager } from "@/game/FragmentManager";
import { IlluminationController } from "@/game/IlluminationController";
import { AudioManager } from "@/game/AudioManager";

type TouchAxis = { forward: number; right: number };
type AudioPreferences = { muted?: boolean; volume?: number };

export class GameWorld {
  readonly player: PlayerController;
  private readonly scene: Scene;
  private readonly canvas: HTMLCanvasElement;
  private readonly fragments: FragmentManager;
  private readonly illumination: IlluminationController;
  private readonly roomAnimator: RoomAnimator;
  private readonly audio = new AudioManager();
  private phase: GamePhase = "intro";
  private hint = "Une lumière veille encore…";
  private canInteract = false;
  private collecting = false;
  private readonly timeouts: number[] = [];
  private readonly onCommand: EventListener;
  private readonly onPointer: (event: PointerEvent) => void;
  private readonly onTouchMove: EventListener;
  private readonly onAudio: EventListener;

  constructor(scene: Scene, canvas: HTMLCanvasElement) {
    this.scene = scene;
    this.canvas = canvas;
    const art = new RoomBuilder(scene).build();
    this.player = new PlayerController(scene, canvas);
    this.fragments = new FragmentManager(scene);
    this.illumination = new IlluminationController(art);
    this.roomAnimator = new RoomAnimator(art);
    this.scene.activeCamera = this.player.camera;

    this.onCommand = ((event: CustomEvent<"start" | "reset" | "interact">) => {
      if (event.detail === "start") this.start(true);
      if (event.detail === "reset") window.location.href = window.location.pathname;
      if (event.detail === "interact") this.interact();
    }) as EventListener;
    this.onTouchMove = ((event: CustomEvent<TouchAxis>) => this.player.setTouchAxis(event.detail)) as EventListener;
    this.onAudio = ((event: CustomEvent<AudioPreferences>) => this.audio.setSettings(event.detail)) as EventListener;
    this.onPointer = (event) => {
      if (event.button === 0 && this.phase === "exploring") this.interact();
    };
    window.addEventListener("eclat:command", this.onCommand);
    window.addEventListener("eclat:move", this.onTouchMove);
    window.addEventListener("eclat:audio", this.onAudio);
    canvas.addEventListener("pointerdown", this.onPointer);
    this.dispatch();
  }

  start(requestPointerLock: boolean) {
    if (this.phase !== "intro") return;
    this.phase = "exploring";
    this.hint = "Approche un porte-clés, puis clique ou touche RECUEILLIR.";
    this.audio.start();
    this.player.start(requestPointerLock);
    this.dispatch();
  }

  update(now: number) {
    this.roomAnimator.update(now);
    if (this.phase === "intro") return;
    this.player.update(Math.min(this.scene.getEngine().getDeltaTime() / 1000, .05));
    const canInteract = !this.collecting && this.phase === "exploring" && this.fragments.update(this.player.camera, now / 1000);
    if (canInteract !== this.canInteract) {
      this.canInteract = canInteract;
      this.dispatch();
    }
    if (this.phase === "awakening" && this.illumination.update(now)) {
      this.phase = "complete";
      this.hint = "La chambre est presque complète…";
      this.canInteract = false;
      this.dispatch();
    }
  }

  runDemo(mode: string | null) {
    if (mode === "final") {
      this.timeouts.push(window.setTimeout(() => this.forceFinal(), 80));
      return;
    }
    if (mode === "showcase") {
      this.timeouts.push(window.setTimeout(() => this.start(false), 220));
      return;
    }
    if (mode === "collect") {
      this.timeouts.push(window.setTimeout(() => this.start(false), 120));
      this.timeouts.push(window.setTimeout(() => this.demoCinematic(1), 2400));
      return;
    }
    this.timeouts.push(window.setTimeout(() => this.start(false), 220));
    [1, 2, 3, 4, 5].forEach((id, index) => this.timeouts.push(window.setTimeout(() => this.demoCollect(id), 1000 + index * 1450)));
  }

  dispose() {
    window.removeEventListener("eclat:command", this.onCommand);
    window.removeEventListener("eclat:move", this.onTouchMove);
    window.removeEventListener("eclat:audio", this.onAudio);
    this.canvas.removeEventListener("pointerdown", this.onPointer);
    this.timeouts.forEach((id) => window.clearTimeout(id));
    this.player.dispose();
    this.audio.dispose();
  }

  private interact() {
    if (this.phase !== "exploring" || this.collecting) return;
    const fragment = this.fragments.tryCollectFromCamera(this.player.camera);
    if (!fragment) return;
    this.collecting = true;
    this.canInteract = false;
    this.audio.fragment(fragment.id);
    window.dispatchEvent(new CustomEvent("eclat:keychain", { detail: fragment }));
    this.dispatch();
    this.timeouts.push(window.setTimeout(() => {
      this.collecting = false;
      this.resolveFragment(fragment.id, fragment.label, fragment.message);
    }, 2600));
  }

  private demoCollect(id: number) {
    if (this.phase === "intro") this.start(false);
    const fragment = this.fragments.collectById(id);
    if (!fragment) return;
    this.resolveFragment(fragment.id, fragment.label, fragment.message);
  }

  private demoCinematic(id: number) {
    const fragment = this.fragments.collectById(id);
    if (!fragment) return;
    this.collecting = true;
    this.audio.fragment(fragment.id);
    window.dispatchEvent(new CustomEvent("eclat:keychain", { detail: fragment }));
    this.timeouts.push(window.setTimeout(() => {
      this.collecting = false;
      this.resolveFragment(fragment.id, fragment.label, fragment.message);
    }, 2600));
  }

  private resolveFragment(id: number, label: string, message: string) {
    const count = this.fragments.count;
    this.illumination.onFragment(count);
    this.canInteract = false;
    if (count === 4) {
      this.hint = "Le puzzle mural s’éveille. La dernière pièce t’attend.";
    } else if (count === 5) {
      this.phase = "awakening";
      this.hint = `${label} — ${message}`;
      this.illumination.beginFinal(performance.now());
      this.audio.finale();
    } else {
      this.hint = `${label} — ${message}`;
    }
    this.dispatch();
  }

  private forceFinal() {
    this.phase = "exploring";
    this.player.start(false);
    for (let id = 1; id <= 5; id++) this.fragments.collectById(id);
    this.illumination.forceComplete();
    this.phase = "complete";
    this.hint = "La chambre est presque complète…";
    this.canInteract = false;
    this.dispatch();
  }

  private dispatch() {
    const snapshot: GameSnapshot = { phase: this.phase, fragments: this.fragments.count, hint: this.hint, canInteract: this.canInteract };
    window.dispatchEvent(new CustomEvent<GameSnapshot>("eclat:state", { detail: snapshot }));
  }
}
