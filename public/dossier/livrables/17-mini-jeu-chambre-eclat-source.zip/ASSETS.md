# Assets — Puzzle Éclat

## Direction artistique active

**ÉCLAT** adopte désormais une chambre claire, tangible et contemporaine : porcelaine ivoire, cyan poudre, sauge, corail, abricot et rose poudré. Le système est directement aligné sur le brandboard fourni : formes de puzzle arrondies, matières artisanales mates, lumière douce et mobilier enfantin en volumes 3D.

## Textures de décor

| Nom | Rôle | Source locale | URL WebDev |
| --- | --- | --- | --- |
| Papier peint puzzle porcelaine | Vraies pièces de puzzle imbriquées, sans pastilles ni motifs abstraits | `/home/ubuntu/webdev-static-assets/puzzle-eclat/eclat-puzzle-wallpaper-v2-mobile.png` | `/manus-storage/eclat-puzzle-wallpaper-v2-mobile_77f30ec3.png` |
| Tapis puzzle | Tissu tufté coloré au centre de la chambre | `/home/ubuntu/webdev-static-assets/puzzle-eclat/eclat-puzzle-rug-mobile.png` | `/manus-storage/eclat-puzzle-rug-mobile_608700f2.png` |
| Parquet bouleau | Sol clair avec micro-incrustations cyan et corail | `/home/ubuntu/webdev-static-assets/puzzle-eclat/eclat-light-wood-floor-mobile.png` | `/manus-storage/eclat-light-wood-floor-mobile_4e3159c5.png` |
| Tableau mural puzzle lumineux | Grandes pièces imbriquées avec liserés lumineux, encadrées sur le mur du fond | `/home/ubuntu/webdev-static-assets/puzzle-eclat/eclat-puzzle-wall-art-v2-mobile.png` | `/manus-storage/eclat-puzzle-wall-art-v2-mobile_b5bbb781.png` |

## Mobilier et objets modélisés dans Babylon

| Zone | Objets 3D |
| --- | --- |
| Lit | Cadre, tête et pied de lit, matelas, couette, repli, oreillers, montants, table de nuit et lampe. |
| Bureau | Plateau, pieds, caisson, tiroirs, chaise à roulettes, feuilles, pot à crayons et lampe. |
| Rangement | Armoire deux portes avec poignées, bibliothèque, livres, plante, pot lumineux et coffre à jouets. |
| Vie de chambre | Fenêtre, rideaux, tableau mural, fauteuil, table d’appoint, mobile, tapis, maison de poupée et balle. |

Les repères lumineux, le mobile et le panneau mural emploient maintenant des **pièces de puzzle extrudées en 3D** (onglets et encoches réels, via CSG Babylon), plutôt que des pastilles rondes.

## Collectibles
Les cinq porte-clés puzzle conservent leurs sprites transparents dédiés. Ils sont présentés par un support 3D (anneau, chaîne, silhouette, aura) dans la chambre et par une cinématique de récupération dans l’interface.
