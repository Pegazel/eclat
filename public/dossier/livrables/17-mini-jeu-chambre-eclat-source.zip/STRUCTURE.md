# Structure — Puzzle Éclat

## Runtime layers

```text
React / GameCanvas (lifecycle-safe frame)
  └─ createGameScene(engine, canvas)
      ├─ GameWorld (room geometry, progression state, update loop)
      ├─ PlayerController (keyboard, drag look, touch, raycast interaction)
      ├─ FragmentManager (five interactables, proximity state, collection)
      ├─ RoomBuilder (materials, furniture, zones, mural, particles)
      ├─ RoomAnimator (idle motion for curtains, pages, plants, castle, mobile)
      ├─ IlluminationController (ambient/zone/final wake-up animations)
      ├─ AudioManager (gesture-unlocked ambience, chimes, volume settings)
      ├─ DemoDirector (?demo deterministic presentation)
      └─ UIController (custom DOM events ↔ HUD/start/end layers)
```

## Source ownership

| File | Ownership |
| --- | --- |
| `client/src/components/GameCanvas.tsx` | Creates/disposes Babylon Engine, renders only the canvas. |
| `client/src/game/scene.ts` | Public engine entry point, DOM state events, scene lifecycle, lightweight orchestration. |
| `client/src/game/GameWorld.ts` | Room state machine: idle, exploring, awakening, complete; central update loop. |
| `client/src/game/RoomBuilder.ts` | Procedural interior meshes, material library, furniture, mural, star ceiling, light nodes. |
| `client/src/game/RoomAnimator.ts` | Time-based idle transforms for fabric, foliage, pages, castle components, mobile, and light props. |
| `client/src/game/FragmentManager.ts` | Fragment creation, center-ray interaction, proximity cue, collectible animation. |
| `client/src/game/PlayerController.ts` | Semantic movement/look/interact inputs and event-mode-safe pointer lock. |
| `client/src/game/IlluminationController.ts` | Zone light values, fragment feedback, floor-wave finale, particles. |
| `client/src/game/AudioManager.ts` | Browser Web Audio ambience, discovery chimes, finale chord, and user volume/mute preferences. |
| `client/src/game/assets.ts` | Generated WebDev storage texture URLs. |
| `client/src/pages/Home.tsx` | Story/interaction overlays and event reset controls only. |

## State contract

```ts
type GamePhase = "intro" | "exploring" | "awakening" | "complete";

interface GameSnapshot {
  phase: GamePhase;
  fragments: number;
  hint: string;
  canInteract: boolean;
}
```

Babylon modules dispatch `CustomEvent("eclat:state", { detail: GameSnapshot })`; React consumes the event to render UI. React never owns or mutates game physics, Babylon meshes, or progress.

Additional one-way UI events are intentionally narrow: `eclat:move` carries normalized joystick axes, `eclat:audio` carries mute/volume preferences, and `eclat:keychain` carries a successful pickup to the React-only close-up cinematic.

## Asset hints
- Generated `puzzle-mural-texture.png` is a 6m × 3.4m wall mural plane at `z=8.82`.
- Generated `star-paper-texture.png` tiles in the 18m × 10m room wall material.
- Main furniture stays procedural and deliberately rounded/simplified: bed (4m), desk (3m), shelf (2m), fragments (0.55m).
- Final particles use thin emissive spheres/points rather than a costly shader.
