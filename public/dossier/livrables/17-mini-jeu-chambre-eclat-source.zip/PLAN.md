# Game Plan: Puzzle Éclat — La Chambre Éclat

## Experience goal
A 3–5 minute first-person exploration in one compact magical bedroom. The player follows the warmth of **L’Éclat**, discovers five luminous fragments across five recognizable zones, and sees the room transform before receiving the physical-event clue **ÉTOILE — EST — 08**.

## Visual target
The playable scene follows `reference-chambre-eclat.png`: midnight indigo paper walls, crafted warm wood furniture, muted violet shadow, and controlled gold/mint/lilac light. The game begins at roughly 10% illumination and ends in a fully awakened room.

## Risk Tasks

### 1. First-person pointer-lock and event fallback
- **Why isolated:** Pointer lock requires a gesture and can be unavailable in an embedded event browser.
- **Approach:** Start button attempts pointer lock; mouse-drag fallback remains available. WASD/arrows move in a bounded room, and click/tap uses a center-screen raycast. Event mode exposes a visible reset control.
- **Verify:** After starting, WASD movement and mouse look work; Escape leaves pointer lock without blocking movement; clicking a nearby fragment works with or without lock.

### 2. Progressive illumination and final activation
- **Why isolated:** The emotional payoff depends on multiple materials, lights, particles, and DOM states moving together without a sudden scene swap.
- **Approach:** A single progression state drives ambient light, zone lights, emissive intensities, fragment count, particle density, mural pieces, narrative copy, and a 7-second final wake-up sequence.
- **Verify:** Each pickup visibly changes one room zone; pickup five triggers a continuous floor-to-wall-to-ceiling light wave before the final clue overlay appears.

## Main Build
- **Environment:** One collision-bounded bedroom with a bed/castle corner, explorer desk, botanical shelf, star path on the floor, and puzzle mural wall.
- **Core loop:** Find a glowing fragment, approach it, click/tap it, get an immediate light/audio-like visual response, then follow the next visual cue.
- **Interactions:** Five large, readable floating fragment objects, with proximity pulse, center reticle hint, narrative toast, and optional demo autopilot.
- **Camera:** `UniversalCamera` first-person view, desktop keyboard/mouse and touch drag/tap, plus deterministic `?demo` sequence for review.
- **UI:** Start screen, ultra-light HUD, ephemeral narrative toast, collectible count, event reset, and French final clue card.
- **Assets needed:** Generated scene reference; generated jigsaw mural texture on the main wall; generated star-paper texture across the room walls. Furniture, lights, fragments, puzzle pieces, and particles are procedural Babylon meshes so the scene remains fast and coherent.
- **Verify:**
  - Movement direction matches input and remains inside the room.
  - Click/tap raycast identifies only the intended fragment meshes.
  - Each fragment updates the HUD and visibly brightens a distinct zone.
  - Mural displays four filled pieces plus one deliberately empty slot until the final sequence.
  - Desktop and narrow event/tablet layouts keep UI legible without crowding the canvas.
  - `pnpm check` and `pnpm build` pass.
  - No browser console errors during screenshot capture.
  - Reference consistency: midnight-indigo palette, crafted room scale, sparse cinematic UI, warm magical lighting.
- **Presentation proof:** `?demo` runs a deterministic discovery sequence and ends on the physical clue.

## Realism and access upgrade
- **Tactile room:** Generated walnut-inlay, quilted velvet, and moonlit curtain textures are applied to the procedural furniture. The bed, desk, shelf, reading nook, castle, window and mobile must read as distinct hand-crafted room objects, not placeholder primitives.
- **Ambient life:** Curtains, book pages, plants, castle components, mobile ornaments and lamp halos each receive a restrained repeating idle motion through `RoomAnimator`.
- **Collectible payoff:** A collected keychain triggers a short DOM close-up cinematic with the actual themed sprite, then resolves progression and its chime.
- **Phone-first play:** A persistent left virtual joystick drives semantic movement; the right side remains free for touch-look; a visible **RECUEILLIR** control handles pickup without keyboard/pointer lock. Sound and volume settings are available in the HUD.
- **Verify:** Desktop and 390px layouts show readable HUD, joystick and collect button; `?demo=showcase` shows animated room furniture and an uncollected keychain; `?demo=collect` triggers the close-up cinematic.
