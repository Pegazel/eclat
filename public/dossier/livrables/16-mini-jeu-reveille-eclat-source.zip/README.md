# Réveille l’Éclat — Puzzle Éclat

A polished, static web mini-game for the **Puzzle Éclat** launch activation. The player rotates physical-looking light-path tiles, restores five illustrated worlds and receives a final clue for the physical labyrinth journey.

## Run locally

```bash
pnpm install
pnpm dev
```

The project is a client-only React + TypeScript + Vite build. No backend, account, API key or database is required.

## Play modes

| URL parameter | Behaviour |
| --- | --- |
| none | Solo website experience; the final clue is an invitation to continue the adventure. |
| `?event=true` | Event kiosk mode; removes external navigation and adds the direction to the final physical-labyrinth clue. |
| `?demo` | Deterministic auto-play mode used for visual QA; it completes every puzzle then shows the final sequence. |

Parameters can be combined: `?event=true&demo`.

## Core gameplay

Each authored path is stored in `client/src/game/levels.ts`. `client/src/game/puzzle.ts` derives line/angle topology, shuffles every tile through a non-zero rotation, and performs breadth-first energy propagation from source to destination. A level only completes when the destination is truly reached through its outbound connection.

The five levels deliberately rise from a 3×3 château introduction to a 5×5 jungle finale. Restarting creates a fresh solvable rotation seed; the final clue is selected from exactly four approved symbol/number/direction combinations. Every correct connection makes the scene brighter by reducing the dark veil, increasing the illustrated-world exposure and expanding the ambient glow. Each world also has its own AI-generated soft light signature, played only after a successful connection or final illumination.

## Brand assets

Illustrated scene plates are hosted in WebDev storage and listed in [`ASSETS.md`](./ASSETS.md). Keep new large runtime media outside the repository, upload it with `manus-upload-file --webdev`, then add the returned `/manus-storage/...` URL to `levels.ts`.

## Project map

| Location | Responsibility |
| --- | --- |
| `client/src/components/GameOverlay.tsx` | Intro, tutorial, HUD, score, final clue UI and responsive puzzle rendering |
| `client/src/game/levels.ts` | Themed level configurations and clue catalogue |
| `client/src/game/puzzle.ts` | Tile rotations, validation, energy propagation and score calculation |
| `client/src/game/scene.ts` | Lifecycle-safe Babylon atmospheric scene |
| `client/src/game/audio.ts` | Optional, gesture-safe soft chime system |
| `PLAN.md`, `STRUCTURE.md`, `MEMORY.md`, `ASSETS.md` | Resumable game-development context |

## Quality checks performed

- `pnpm check` passes.
- `pnpm build` passes.
- All five solved configurations are programmatically verified; multiple seeded starting arrangements are confirmed unresolved and solvable.
- Browser interaction verified: intro → tutorial → live tile rotation → progressive world illumination → themed sound playback → score/movement tracking → fifth-level finale → final clue.
- Desktop and 390 px mobile event-mode visuals were checked, with no browser-console output.
