# Game Plan: Réveille l’Éclat

## Visual target
A premium, tactile miniature-world browser game: deep navy storybook scenes sit behind painted coral, teal, sage and gold puzzle pieces. A brass key ring is the visual and narrative anchor; each completed world adds a collectible charm to it. Fine curved light filaments restore a named landmark rather than simply filling a generic circuit.

## Risk Tasks

### 1. Data-driven rotational circuit solver
- **Why isolated:** A puzzle may look valid while leaking energy, accepting an invalid route, or shipping an impossible initial state.
- **Approach:** Define every level as a fixed coordinate path. Derive each tile’s final connection directions from adjacent path coordinates, then initialize it with non-zero seeded rotations. Run breadth-first propagation from the source on every interaction; completion requires reaching the destination through its outward exit.
- **Verify:** For each of the five levels, setting every tile to orientation `0` reaches the target; each seeded start is solvable via rotation and begins unresolved.

### 2. Completion and finale handoff
- **Why isolated:** Overlapping level timers can skip a world, award score twice, or hide the final clue.
- **Approach:** Use explicit phases (`intro`, `tutorial`, `playing`, `final`) plus a per-level completion guard. Completion locks input, displays the light propagation, awards Éclats once, then advances after a short readable celebration. The final level transitions to a staged finale with a randomized clue.
- **Verify:** Repeated clicks after completion do not change score; the fifth completion always reaches the clue panel; replay generates a new solvable arrangement and selects a valid clue.

## Main Build

- Full-screen React host with a lightweight Babylon.js starfield layer and DOM gameplay/HUD overlay.
- Five configured worlds: château magique, bateau pirate, forêt enchantée, circuit nocturne and jungle perdue, each with a named objective and three concrete scene-reveal milestones.
- Responsive touch-first full puzzle surface: all cells form complementary jigsaw pieces; only pieces with light filaments rotate, while the rest are fixed décor.
- Keychain source, themed destination marker, collectible completion charm, timer, movement count, accessibility labels, restart and sound controls.
- Soft Web Audio chimes unlocked on interaction; sound is optional and always toggleable.
- `?event=true` removes outward navigation cues and enlarges the activation experience; `?demo` performs a deterministic visual solve for review screenshots.
- **Assets:** five generated 2560×1440 scene plates used as full-screen backgrounds and a generated in-game visual target used in the intro/finale.

## Verification

- `pnpm check` and `pnpm build` pass.
- Browser screenshots show the intro, a live game board, and the final clue at desktop and mobile sizes.
- All five paths resolve only when the source-to-destination connection is genuinely continuous.
- Touch-sized controls remain visible without hover, text maintains contrast, and reduced-motion rules prevent non-essential animation.
- No missing image, console error, placeholder screen, or unimplemented primary control is visible.
