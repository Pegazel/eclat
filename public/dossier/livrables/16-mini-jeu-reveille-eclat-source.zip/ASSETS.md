# Assets

**Art direction:** A tactile miniature-world adventure: deep midnight navy and storybook landscapes behind painted coral, teal, sage and gold jigsaw pieces. The visual anchor is a brass key ring carrying collectible puzzle charms; illumination is a concrete reward that restores a specific part of each world.

## Backgrounds

| Name | Description | Size | Runtime URL |
| --- | --- | --- | --- |
| keychain opening | Cinematic tabletop scene with a brass key ring and interlocking coral, teal and sage puzzle charms | 2560×1440, opening / tutorial full viewport | `/manus-storage/eclat-keychain-opening_a915f2e1.jpg` |
| visual target | In-game reference: unicorn forest, ivory puzzle grid, cyan/gold light | 2560×1440, intro/finale full viewport | `/manus-storage/eclat-visual-target_a4a1c369.png` |
| castle | Moonlit château magique with waking gold windows | 2560×1440, level 1 full viewport | `/manus-storage/castle-magic-background_c354d5f6.png` |
| pirate | Blue-hour pirate harbor and lighthouse | 2560×1440, level 2 full viewport | `/manus-storage/pirate-lighthouse-background_95050baf.png` |
| unicorn | Enchanted forest and luminous unicorn | 2560×1440, level 3 full viewport | `/manus-storage/unicorn-forest-background_12ddf715.png` |
| racing | Night circuit with rounded racing car | 2560×1440, level 4 full viewport | `/manus-storage/racing-night-background_6cf9c618.png` |
| jungle | Lost jungle with friendly dinosaurs and luminous ruins | 2560×1440, level 5 full viewport | `/manus-storage/jungle-dinosaur-background_8830c65a.png` |

## Procedural UI assets

| Name | Description | Size | Runtime |
| --- | --- | --- | --- |
| interlocking puzzle surface | Complementary, physical SVG jigsaw edges; path pieces rotate while non-path pieces become fixed world décor | Responsive DOM / SVG | React / CSS / SVG |
| light filaments | Fine curved engraved filaments with a dim inactive state, an animated lit state and endpoint sparks | Responsive SVG | React / CSS / SVG |
| keychain collection | Brass ring with per-world collectible charms, used as source, completion reward and finale trophy | Responsive DOM / SVG | React / CSS / SVG |
| world objectives | Theme-specific destination motifs and three tangible story-reveal milestones per world | Responsive DOM / SVG | React / CSS / SVG |
| stars | Ambient points of light behind the interface | 1–3 px | Babylon scene |

## Sound effects

| Name | Description | Runtime URL |
| --- | --- | --- |
| castle light | Warm glass chimes and tiny bell | `/manus-storage/castle-light_bd5e0dab.mp3` |
| pirate light | Lantern sparkle with a polished ship bell | `/manus-storage/pirate-light_35a4258d.mp3` |
| unicorn light | Airy harp and crystal shimmer | `/manus-storage/unicorn-light_86f30a01.mp3` |
| racing light | Gentle electric hum into a synth chime | `/manus-storage/racing-light_ffda732c.mp3` |
| jungle light | Leaf rustle, mellow marimba and sparkle | `/manus-storage/jungle-light_4a006020.mp3` |
