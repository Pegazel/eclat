# Implementation Memory

- WebDev static host initialized at `/home/ubuntu/puzzle-eclat`.
- Babylon.js is intentionally limited to a lifecycle-safe ambient rendering layer; the tile grid is DOM/SVG to make rotation and touch interaction reliable on tablets.
- All runtime artwork is uploaded to WebDev storage rather than committed to the repository.
- Puzzle paths are authored as coordinate arrays and derive their own line/angle topology. This ensures every randomized start remains solvable by restoring rotations to zero.
- `?event=true` is the event-kiosk variant. `?demo` auto-solves seeded boards for visual review.
- The playable surface now generates all grid cells. Path cells are interactive; non-path cells have no connections and are rendered as fixed, muted décor so the board never looks incomplete.
- Complementary jigsaw edges are generated deterministically from grid coordinates, ensuring neighbouring tiles visually lock together.
- Each level owns a named landmark and three visible story beats. Completing a level adds a themed charm to the keychain collection; the finale shows the completed keychain instead of a generic star.
