import { ArcRotateCamera } from "@babylonjs/core/Cameras/arcRotateCamera";
import { Color3, Color4 } from "@babylonjs/core/Maths/math.color";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { Engine } from "@babylonjs/core/Engines/engine";
import { GlowLayer } from "@babylonjs/core/Layers/glowLayer";
import { HemisphericLight } from "@babylonjs/core/Lights/hemisphericLight";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
import { Scene } from "@babylonjs/core/scene";

export interface GameHandle {
  scene: Scene;
  dispose: () => void;
}

export async function createGameScene(engine: Engine, _canvas: HTMLCanvasElement): Promise<GameHandle> {
  const scene = new Scene(engine);
  scene.clearColor = new Color4(0.012, 0.027, 0.09, 1);

  const camera = new ArcRotateCamera("constellation-camera", -Math.PI / 2, Math.PI / 2.35, 16, Vector3.Zero(), scene);
  camera.lowerRadiusLimit = 16;
  camera.upperRadiusLimit = 16;

  const light = new HemisphericLight("midnight-light", new Vector3(0, 1, 0), scene);
  light.intensity = 0.2;

  const glow = new GlowLayer("soft-starlight", scene, { blurKernelSize: 36 });
  glow.intensity = 0.65;

  const stars = Array.from({ length: 36 }, (_, index) => {
    const star = MeshBuilder.CreateSphere(`star-${index}`, { diameter: index % 5 === 0 ? 0.075 : 0.036, segments: 6 }, scene);
    const angle = (index * 2.399) % (Math.PI * 2);
    const distance = 5 + ((index * 13) % 70) / 10;
    star.position = new Vector3(Math.cos(angle) * distance, -3 + ((index * 17) % 60) / 10, Math.sin(angle) * distance - 2);

    const material = new StandardMaterial(`star-material-${index}`, scene);
    const warm = index % 3 === 0;
    material.emissiveColor = warm ? new Color3(1, 0.72, 0.24) : new Color3(0.25, 0.75, 1);
    material.alpha = 0.25 + (index % 6) * 0.08;
    star.material = material;
    return star;
  });

  scene.onBeforeRenderObservable.add(() => {
    const time = performance.now() * 0.001;
    stars.forEach((star, index) => {
      star.position.y += Math.sin(time * 0.75 + index) * 0.0009;
      star.rotation.z += 0.001;
    });
    camera.alpha = -Math.PI / 2 + Math.sin(time * 0.05) * 0.04;
  });

  return {
    scene,
    dispose: () => {
      glow.dispose();
      scene.dispose();
    },
  };
}
