import type { LevelTheme } from "./levels";

export type SoundCue = "rotate" | "complete";

const THEME_SOUND_URLS: Record<LevelTheme, string> = {
  castle: "/manus-storage/castle-light_bd5e0dab.mp3",
  pirate: "/manus-storage/pirate-light_35a4258d.mp3",
  unicorn: "/manus-storage/unicorn-light_86f30a01.mp3",
  racing: "/manus-storage/racing-light_ffda732c.mp3",
  jungle: "/manus-storage/jungle-light_4a006020.mp3",
};

const AMBIENT_URL = "/manus-storage/eclat-continuous-ambience_8f98c3a1.mp3";

let audioContext: AudioContext | null = null;
let ambientPlayer: HTMLAudioElement | null = null;
const themedPlayers = new Map<LevelTheme, HTMLAudioElement>();

function getContext() {
  if (!audioContext) audioContext = new AudioContext();
  if (audioContext.state === "suspended") void audioContext.resume();
  return audioContext;
}

/** Starts once after the player's first gesture, then loops quietly behind every level. */
export function startAmbientMusic(enabled: boolean) {
  if (!enabled || typeof window === "undefined") return;
  try {
    if (!ambientPlayer) {
      ambientPlayer = new Audio(AMBIENT_URL);
      ambientPlayer.loop = true;
      ambientPlayer.preload = "auto";
      ambientPlayer.volume = 0.18;
    }
    void ambientPlayer.play().catch(() => undefined);
  } catch {
    // Background ambience is never required for play.
  }
}

export function stopAmbientMusic() {
  ambientPlayer?.pause();
}

export function playThemeSound(theme: LevelTheme, enabled: boolean, isFinalLight = false) {
  if (!enabled || typeof window === "undefined") return;

  try {
    let player = themedPlayers.get(theme);
    if (!player) {
      player = new Audio(THEME_SOUND_URLS[theme]);
      player.preload = "auto";
      themedPlayers.set(theme, player);
    }
    player.pause();
    player.currentTime = 0;
    player.volume = isFinalLight ? 0.48 : 0.3;
    void player.play().catch(() => undefined);
  } catch {
    // Sounds are a reward layer only and never interrupt gameplay.
  }
}

export function playSound(cue: SoundCue, enabled: boolean) {
  if (!enabled || typeof window === "undefined") return;

  try {
    const context = getContext();
    const now = context.currentTime;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const frequencies: Record<SoundCue, [number, number, number]> = {
      rotate: [349, 418, 0.08],
      complete: [523, 784, 0.42],
    };
    const [from, to, duration] = frequencies[cue];

    oscillator.type = cue === "rotate" ? "sine" : "triangle";
    oscillator.frequency.setValueAtTime(from, now);
    oscillator.frequency.exponentialRampToValueAtTime(to, now + duration);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(cue === "complete" ? 0.07 : 0.035, now + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration + 0.025);
  } catch {
    // Browser audio restrictions should never interrupt a puzzle action.
  }
}
