export type Coord = readonly [number, number];

export type LevelTheme = "castle" | "pirate" | "unicorn" | "racing" | "jungle";

export interface LevelConfig {
  id: number;
  theme: LevelTheme;
  world: string;
  title: string;
  subtitle: string;
  size: number;
  difficulty: string;
  tip: string;
  objective: string;
  reveal: readonly [string, string, string];
  accent: string;
  background: string;
  source: Coord;
  target: Coord;
  path: readonly Coord[];
}

export const VISUAL_TARGET_URL = "/manus-storage/eclat-visual-target_a4a1c369.png";
export const OPENING_BACKGROUND_URL = "/manus-storage/eclat-keychain-opening_a915f2e1.jpg";

export const LEVELS: readonly LevelConfig[] = [
  {
    id: 1,
    theme: "castle",
    world: "Château magique",
    title: "La première lueur",
    subtitle: "Réveille les fenêtres du château.",
    size: 3,
    difficulty: "Initiation",
    tip: "Tourne les pièces qui portent un filament de lumière.",
    objective: "Fenêtres du château",
    reveal: ["Le portail retrouve sa lueur", "Les tours rallument leurs lanternes", "Les fenêtres du château brillent"],
    accent: "#ffe49a",
    background: "/manus-storage/castle-magic-background_c354d5f6.png",
    source: [1, 0],
    target: [1, 2],
    path: [
      [1, 0], [0, 0], [0, 1], [1, 1], [2, 1], [2, 2], [1, 2],
    ],
  },
  {
    id: 2,
    theme: "pirate",
    world: "Bateau pirate",
    title: "Le phare perdu",
    subtitle: "Rallume la route du capitaine.",
    size: 4,
    difficulty: "Exploration",
    tip: "Le filament s'allume dès qu'il sort dans la bonne direction.",
    objective: "Lanterne du capitaine",
    reveal: ["Le quai sort de la brume", "La boussole scintille", "La lanterne guide le bateau"],
    accent: "#78e7f5",
    background: "/manus-storage/pirate-lighthouse-background_95050baf.png",
    source: [1, 0],
    target: [2, 3],
    path: [
      [1, 0], [0, 0], [0, 1], [0, 2], [1, 2], [2, 2], [2, 1], [3, 1], [3, 2], [3, 3], [2, 3],
    ],
  },
  {
    id: 3,
    theme: "unicorn",
    world: "Forêt enchantée",
    title: "La clairière des étoiles",
    subtitle: "Fais danser la lumière jusqu’à la licorne.",
    size: 4,
    difficulty: "Magie",
    tip: "Les pièces sans filament font partie du décor : elles restent fixes.",
    objective: "Cristal de la clairière",
    reveal: ["Les fougères reprennent couleur", "Les lucioles se réveillent", "Le cristal appelle la licorne"],
    accent: "#d3b4ff",
    background: "/manus-storage/unicorn-forest-background_12ddf715.png",
    source: [1, 0],
    target: [1, 3],
    path: [
      [1, 0], [0, 0], [0, 1], [1, 1], [2, 1], [2, 0], [3, 0], [3, 1], [3, 2], [2, 2], [1, 2], [1, 3],
    ],
  },
  {
    id: 4,
    theme: "racing",
    world: "Course automobile",
    title: "Le circuit des comètes",
    subtitle: "Remets les phares sur la bonne trajectoire.",
    size: 5,
    difficulty: "Énergie",
    tip: "Fais suivre la lueur jusqu'au portique de départ.",
    objective: "Portique de départ",
    reveal: ["La piste apparaît dans la nuit", "Les phares clignotent", "Le portique lance la course"],
    accent: "#ff9f8b",
    background: "/manus-storage/racing-night-background_6cf9c618.png",
    source: [2, 0],
    target: [2, 4],
    path: [
      [2, 0], [1, 0], [0, 0], [0, 1], [1, 1], [1, 2], [0, 2], [0, 3], [1, 3], [2, 3], [2, 2], [3, 2], [4, 2], [4, 3], [3, 3], [3, 4], [2, 4],
    ],
  },
  {
    id: 5,
    theme: "jungle",
    world: "Le monde perdu",
    title: "La dernière traversée",
    subtitle: "Fais revivre la jungle des géants.",
    size: 5,
    difficulty: "Final",
    tip: "Relie la pièce-clé à la fleur-lanterne pour compléter le porte-clés.",
    objective: "Fleur-lanterne de la jungle",
    reveal: ["Les lianes sortent de l'ombre", "Les lucioles forment une rivière", "La fleur-lanterne réveille la jungle"],
    accent: "#b9ec84",
    background: "/manus-storage/jungle-dinosaur-background_8830c65a.png",
    source: [2, 0],
    target: [2, 4],
    path: [
      [2, 0], [1, 0], [0, 0], [0, 1], [0, 2], [1, 2], [1, 1], [2, 1], [3, 1], [4, 1], [4, 2], [4, 3], [3, 3], [3, 2], [2, 2], [2, 3], [1, 3], [0, 3], [0, 4], [1, 4], [2, 4],
    ],
  },
] as const;

export const CLUES = [
  { symbol: "✦", number: "04", direction: "EST" },
  { symbol: "☀", number: "07", direction: "SUD" },
  { symbol: "☾", number: "12", direction: "NORD" },
  { symbol: "◆", number: "03", direction: "OUEST" },
] as const;

export type Clue = (typeof CLUES)[number];
