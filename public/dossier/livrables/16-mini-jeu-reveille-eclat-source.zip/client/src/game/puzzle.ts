import type { Coord, LevelConfig } from "./levels";

export type Direction = 0 | 1 | 2 | 3;
// 0 = north, 1 = east, 2 = south, 3 = west
export const NORTH: Direction = 0;
export const EAST: Direction = 1;
export const SOUTH: Direction = 2;
export const WEST: Direction = 3;

export interface PuzzleTile {
  id: string;
  row: number;
  col: number;
  baseConnections: readonly Direction[];
  rotation: number;
  turns: number;
  isPath: boolean;
}

export interface PuzzleResolution {
  poweredIds: Set<string>;
  complete: boolean;
}

const keyFor = (row: number, col: number) => `${row}:${col}`;
const idFor = (row: number, col: number) => `tile-${row}-${col}`;

export function opposite(direction: Direction): Direction {
  return ((direction + 2) % 4) as Direction;
}

export function directionBetween(from: Coord, to: Coord): Direction {
  const [fromRow, fromCol] = from;
  const [toRow, toCol] = to;
  if (toRow < fromRow) return NORTH;
  if (toCol > fromCol) return EAST;
  if (toRow > fromRow) return SOUTH;
  return WEST;
}

export function rotateConnections(connections: readonly Direction[], rotation: number): Direction[] {
  return connections.map((direction) => ((direction + rotation) % 4) as Direction);
}

export function isStraightTile(connections: readonly Direction[]) {
  return connections.length === 2 && opposite(connections[0]) === connections[1];
}

export function makePuzzle(level: LevelConfig, seed: number): PuzzleTile[] {
  const pathTiles = new Map<string, { connections: Direction[]; index: number }>();

  level.path.forEach((coord, index) => {
    const [row, col] = coord;
    const connections: Direction[] = [];

    if (index === 0) {
      connections.push(WEST);
    } else {
      connections.push(directionBetween(coord, level.path[index - 1]));
    }

    if (index === level.path.length - 1) {
      connections.push(EAST);
    } else {
      connections.push(directionBetween(coord, level.path[index + 1]));
    }

    pathTiles.set(keyFor(row, col), { connections, index });
  });

  const tiles: PuzzleTile[] = [];
  for (let row = 0; row < level.size; row += 1) {
    for (let col = 0; col < level.size; col += 1) {
      const pathTile = pathTiles.get(keyFor(row, col));
      const rotation = pathTile
        ? ((seed * 17 + (pathTile.index + 1) * 11 + level.id * 5) % 3) + 1
        : 0;
      tiles.push({
        id: idFor(row, col),
        row,
        col,
        baseConnections: pathTile?.connections ?? [],
        rotation,
        turns: rotation,
        isPath: Boolean(pathTile),
      });
    }
  }

  return tiles;
}

export function resolvePuzzle(level: LevelConfig, tiles: readonly PuzzleTile[]): PuzzleResolution {
  const byCoordinate = new Map<string, PuzzleTile>();
  const byId = new Map<string, PuzzleTile>();
  tiles.forEach((tile) => {
    byCoordinate.set(keyFor(tile.row, tile.col), tile);
    byId.set(tile.id, tile);
  });

  const sourceTile = byCoordinate.get(keyFor(level.source[0], level.source[1]));
  const targetId = idFor(level.target[0], level.target[1]);
  if (!sourceTile || !rotateConnections(sourceTile.baseConnections, sourceTile.rotation).includes(WEST)) {
    return { poweredIds: new Set(), complete: false };
  }

  const poweredIds = new Set<string>();
  const queue: PuzzleTile[] = [sourceTile];
  poweredIds.add(sourceTile.id);

  while (queue.length) {
    const current = queue.shift();
    if (!current) break;

    const activeConnections = rotateConnections(current.baseConnections, current.rotation);
    activeConnections.forEach((direction) => {
      const nextRow = current.row + (direction === NORTH ? -1 : direction === SOUTH ? 1 : 0);
      const nextCol = current.col + (direction === EAST ? 1 : direction === WEST ? -1 : 0);
      const next = byCoordinate.get(keyFor(nextRow, nextCol));
      if (!next || poweredIds.has(next.id)) return;

      const nextConnections = rotateConnections(next.baseConnections, next.rotation);
      if (!nextConnections.includes(opposite(direction))) return;

      poweredIds.add(next.id);
      queue.push(next);
    });
  }

  const target = byId.get(targetId);
  const complete = Boolean(
    target && poweredIds.has(targetId) && rotateConnections(target.baseConnections, target.rotation).includes(EAST),
  );

  return { poweredIds, complete };
}

export function completedPuzzle(level: LevelConfig): PuzzleTile[] {
  return makePuzzle(level, 0).map((tile) => ({ ...tile, rotation: 0, turns: 0 }));
}

export function formatTime(seconds: number) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const remainder = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${remainder}`;
}

export function levelPoints(level: LevelConfig, moves: number, seconds: number) {
  return Math.max(180, 920 + level.id * 110 - moves * 13 - seconds * 4);
}
