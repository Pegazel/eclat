import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import {
  Compass,
  Lightbulb,
  RotateCcw,
  RotateCw,
  Sparkles,
  Timer,
  Volume2,
  VolumeX,
} from "lucide-react";
import { CLUES, LEVELS, OPENING_BACKGROUND_URL, VISUAL_TARGET_URL, type Clue, type LevelConfig, type LevelTheme } from "@/game/levels";
import { playSound, playThemeSound, startAmbientMusic, stopAmbientMusic } from "@/game/audio";
import {
  EAST,
  NORTH,
  SOUTH,
  WEST,
  formatTime,
  isStraightTile,
  levelPoints,
  makePuzzle,
  resolvePuzzle,
  type Direction,
  type PuzzleTile,
} from "@/game/puzzle";

type Phase = "intro" | "tutorial" | "playing" | "final";

const endpoint: Record<Direction, [number, number, number, number]> = {
  0: [50, 50, 50, 0],
  1: [50, 50, 100, 50],
  2: [50, 50, 50, 100],
  3: [50, 50, 0, 50],
};

const CURVED_ENDPOINT: Record<Direction, string> = {
  0: "M50 50 C42 38 58 22 50 4",
  1: "M50 50 C63 42 77 58 96 50",
  2: "M50 50 C58 62 42 78 50 96",
  3: "M50 50 C37 58 23 42 4 50",
};

const PIECE_PALETTES: Record<LevelTheme, readonly string[]> = {
  castle: ["#db6655", "#3d8b8b", "#e8bb6b", "#9fad78"],
  pirate: ["#2f7f8b", "#d36b54", "#d3a960", "#7d9c88"],
  unicorn: ["#d7859f", "#6fa8a5", "#e7bd6a", "#9b83c2"],
  racing: ["#de664d", "#2e7884", "#e1b55e", "#80996d"],
  jungle: ["#758f6e", "#d27a55", "#cfad5d", "#4d9290"],
};

function randomSeed() {
  return Math.floor(Date.now() % 100_000) + Math.floor(Math.random() * 10_000);
}

function rankFor(score: number) {
  if (score >= 4_200) return "✦✦✦✦ Maître de l’Éclat";
  if (score >= 3_000) return "✦✦✦ Créateur";
  if (score >= 1_700) return "✦✦ Explorateur";
  return "✦ Apprenti de l’Éclat";
}

function ThemeMotif({ theme }: { theme: LevelTheme }) {
  const motifs: Record<LevelTheme, React.ReactNode> = {
    castle: <><path d="M21 73V39l11 9V31l12 10V25l12 10v-8l12 10v36" /><path d="M20 73h50M31 73V59h10v14M51 73V57h9v16" /><path d="M25 42h4M57 43h4" /></>,
    pirate: <><circle cx="50" cy="50" r="23" /><circle cx="50" cy="50" r="8" /><path d="M50 19v16M50 65v16M19 50h16M65 50h16M29 29l11 11M60 60l11 11M71 29L60 40M40 60L29 71" /></>,
    unicorn: <><path d="M26 66c8-25 24-38 47-33 5 1 10 4 14 8-7 1-11 4-12 9 8 2 12 7 12 14-8-5-15-6-21-2-11 8-23 10-35 4Z" /><path d="m40 36 5-17 7 15M56 43h1M35 68c-5 3-8 6-9 11M57 66c4 4 6 8 6 13" /></>,
    racing: <><path d="M22 65h56l-5-19-13-9H40l-12 9-6 19Z" /><path d="M34 47h32M28 65a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm44 0a8 8 0 1 0 0 16 8 8 0 0 0 0-16Z" /><path d="M40 37l3-10h15l4 10M58 50h8" /></>,
    jungle: <><path d="M51 79c-3-25 2-46 25-58-2 23-13 39-25 58ZM49 79c3-25-2-46-25-58 2 23 13 39 25 58Z" /><path d="M50 72V37M50 54 31 42M50 62l20-13M50 45l13-12M50 42 37 30" /></>,
  };

  return <svg className={`theme-motif motif-${theme}`} viewBox="0 0 100 100" aria-hidden="true">{motifs[theme]}</svg>;
}

function LumenIcon({ tile }: { tile: PuzzleTile }) {
  return (
    <svg viewBox="0 0 100 100" className="lumen-svg" aria-hidden="true">
      <g
        className="lumen-turn"
        style={{
          transform: `rotate(${tile.turns * 90}deg)`,
          transformBox: "fill-box",
          transformOrigin: "center",
        }}
      >
        {tile.baseConnections.map((direction) => {
          const key = `${tile.id}-${direction}`;
          return (
            <g key={key}>
              <path className="lumen-track" d={CURVED_ENDPOINT[direction]} fill="none" />
              <circle className="lumen-spark" cx={endpoint[direction][2]} cy={endpoint[direction][3]} r="2.5" />
            </g>
          );
        })}
        <circle className="lumen-core" cx="50" cy="50" r="7" />
        <circle className="lumen-core-dot" cx="50" cy="50" r="2.2" />
      </g>
    </svg>
  );
}

type EdgeDirection = -1 | 0 | 1;

function edgeSeed(row: number, col: number, axis: "vertical" | "horizontal"): EdgeDirection {
  return ((row * 13 + col * 7 + (axis === "vertical" ? 3 : 0)) % 2 === 0 ? 1 : -1);
}

function horizontalEdge(from: number, to: number, y: number, bulge: number) {
  if (!bulge) return `L ${to} ${y}`;
  const span = to - from;
  const a = from + span * 0.31;
  const b = from + span * 0.39;
  const c = from + span * 0.46;
  const d = from + span * 0.54;
  const e = from + span * 0.61;
  const f = from + span * 0.69;
  return `L ${a} ${y} C ${b} ${y} ${b} ${y + bulge * 0.86} ${c} ${y + bulge} C ${d} ${y + bulge * 1.16} ${e} ${y + bulge * 0.86} ${e} ${y} L ${f} ${y} L ${to} ${y}`;
}

function verticalEdge(x: number, from: number, to: number, bulge: number) {
  if (!bulge) return `L ${x} ${to}`;
  const span = to - from;
  const a = from + span * 0.31;
  const b = from + span * 0.39;
  const c = from + span * 0.46;
  const d = from + span * 0.54;
  const e = from + span * 0.61;
  const f = from + span * 0.69;
  return `L ${x} ${a} C ${x} ${b} ${x + bulge * 0.86} ${b} ${x + bulge} ${c} C ${x + bulge * 1.16} ${d} ${x + bulge * 0.86} ${e} ${x} ${e} L ${x} ${f} L ${x} ${to}`;
}

function PuzzlePieceFrame({ row = 0, col = 0, size = 2 }: { row?: number; col?: number; size?: number }) {
  const top = row === 0 ? 0 : (-edgeSeed(row - 1, col, "vertical") as EdgeDirection);
  const right = col === size - 1 ? 0 : edgeSeed(row, col, "horizontal");
  const bottom = row === size - 1 ? 0 : edgeSeed(row, col, "vertical");
  const left = col === 0 ? 0 : (-edgeSeed(row, col - 1, "horizontal") as EdgeDirection);
  const outline = [
    "M 8 8",
    horizontalEdge(8, 92, 8, -14 * top),
    verticalEdge(92, 8, 92, 14 * right),
    horizontalEdge(92, 8, 92, 14 * bottom),
    verticalEdge(8, 92, 8, -14 * left),
    "Z",
  ].join(" ");

  return (
    <svg className="puzzle-piece-frame" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
      <path className="piece-shadow" d={outline} />
      <path className="piece-fill" d={outline} />
      <path className="piece-sheen" d="M18 17h20c-1-7 4-10 12-10 5 0 9 1 11 5-10-1-12 8-4 12H24c-4 0-6-2-6-7Z" />
      <path className="piece-outline" d={outline} />
    </svg>
  );
}

function KeychainSource() {
  return (
    <svg className="keychain-source" viewBox="0 0 130 165" aria-hidden="true">
      <circle className="key-ring" cx="65" cy="30" r="22" />
      <circle className="key-ring-inner" cx="65" cy="30" r="13" />
      <path className="key-chain" d="M65 53v19M59 75h12v12H59zM59 91h12v12H59zM65 105v13" />
      <g className="key-pendant" transform="translate(28 111)">
        <path d="M3 3h15c-1-7 4-10 10-10s11 3 10 10h15v15c7-1 10 4 10 10s-3 11-10 10v15H38c1 7-4 10-10 10s-11-3-10-10H3V38c-7 1-10-4-10-10S-4 17 3 18V3Z" />
        <path className="key-pendant-line" d="M3 3h15c-1-7 4-10 10-10s11 3 10 10h15v15c7-1 10 4 10 10s-3 11-10 10v15H38c1 7-4 10-10 10s-11-3-10-10H3V38c-7 1-10-4-10-10S-4 17 3 18V3Z" />
        <circle cx="28" cy="28" r="7" className="key-pendant-core" />
      </g>
      <circle className="key-glow" cx="65" cy="140" r="43" />
    </svg>
  );
}

function WorldToken({ theme }: { theme: LevelTheme }) {
  return <div className={`world-token world-token-${theme}`} aria-hidden="true"><ThemeMotif theme={theme} /></div>;
}

function KeychainCollection({ themes, finale = false }: { themes: readonly LevelTheme[]; finale?: boolean }) {
  return (
    <div className={`keychain-collection ${finale ? "is-finale" : ""}`} aria-label={`${themes.length} pièces ajoutées au porte-clés`}>
      <span className="collection-ring" aria-hidden="true" />
      <div className="collection-charms">
        {themes.map((theme, index) => (
          <span className={`collection-charm charm-${theme}`} style={{ "--charm-index": index } as CSSProperties} key={theme}><ThemeMotif theme={theme} /></span>
        ))}
      </div>
    </div>
  );
}

function SceneReveal({ level, progress }: { level: LevelConfig; progress: number }) {
  const unlocked = progress > 0.06 ? progress > 0.68 ? 3 : progress > 0.34 ? 2 : 1 : 0;
  return (
    <section className="scene-reveal" aria-live="polite" aria-label={`Réveil du monde : ${level.objective}`}>
      <div className="scene-reveal-title"><WorldToken theme={level.theme} /><div><span>À RÉVEILLER</span><b>{level.objective}</b></div></div>
      <ol>
        {level.reveal.map((step, index) => <li className={index < unlocked ? "is-awake" : ""} key={step}><i>{index + 1}</i><span>{step}</span></li>)}
      </ol>
    </section>
  );
}

function PuzzleBoard({
  level,
  puzzle,
  poweredIds,
  locked,
  onRotate,
}: {
  level: LevelConfig;
  puzzle: readonly PuzzleTile[];
  poweredIds: Set<string>;
  locked: boolean;
  onRotate: (id: string) => void;
}) {
  const tilesByCell = useMemo(
    () => new Map(puzzle.map((tile) => [`${tile.row}:${tile.col}`, tile])),
    [puzzle],
  );
  const sourceTop = `${((level.source[0] + 0.5) / level.size) * 100}%`;
  const targetTop = `${((level.target[0] + 0.5) / level.size) * 100}%`;
  const pathTileCount = puzzle.filter((tile) => tile.isPath).length;
  const lightPercent = Math.round((poweredIds.size / pathTileCount) * 100);
  const cells = [];

  for (let row = 0; row < level.size; row += 1) {
    for (let col = 0; col < level.size; col += 1) {
      const tile = tilesByCell.get(`${row}:${col}`);
      if (!tile) {
        cells.push(
          <div className="scenery-fallback" key={`empty-${row}-${col}`} aria-hidden="true" />,
        );
        continue;
      }

      const tileName = tile.isPath ? (isStraightTile(tile.baseConnections) ? "rayon" : "éclat") : "décor";
      const palette = PIECE_PALETTES[level.theme];
      const color = palette[(row * level.size + col) % palette.length];
      cells.push(
        <button
          className={`puzzle-tile theme-${level.theme} ${tile.isPath ? "is-path" : "is-scenery"} ${poweredIds.has(tile.id) ? "is-powered" : ""}`}
          disabled={locked || !tile.isPath}
          key={tile.id}
          onClick={() => onRotate(tile.id)}
          style={{ "--piece-fill": color } as CSSProperties}
          aria-label={tile.isPath ? `Pièce ${tileName}, ligne ${row + 1}, colonne ${col + 1}. Cliquez pour tourner.` : `Pièce décorative fixe, ligne ${row + 1}, colonne ${col + 1}.`}
        >
          <PuzzlePieceFrame row={row} col={col} size={level.size} />
          <ThemeMotif theme={level.theme} />
          {tile.isPath && <LumenIcon tile={tile} />}
        </button>,
      );
    }
  }

  return (
    <div className={`board-stage board-${level.theme}`} style={{ "--accent": level.accent } as CSSProperties}>
      <div className="source-node" style={{ top: sourceTop }} aria-label="Porte-clés lumineux, source de lumière"><KeychainSource /><span className="node-label">PIÈCE-CLÉ</span></div>
      <div className="puzzle-grid" style={{ "--grid-size": level.size } as CSSProperties} aria-label={`Puzzle du niveau ${level.id}`}>{cells}</div>
      <div className="target-node" style={{ top: targetTop }} aria-label={`Destination : ${level.objective}`}><WorldToken theme={level.theme} /><span className="node-label">{level.objective}</span></div>
      <div className="light-meter" aria-label={`Lumière réveillée : ${lightPercent}%`}>
        <span>MONDE RÉVEILLÉ</span><div><i style={{ width: `${lightPercent}%` }} /></div><b>{lightPercent}%</b>
      </div>
    </div>
  );
}

function TutorialTile() {
  return (
    <div className="tutorial-tile" style={{ "--piece-fill": "#d86659" } as CSSProperties} aria-hidden="true">
      <PuzzlePieceFrame />
      <svg className="tutorial-filament" viewBox="0 0 100 100"><path d="M50 50 C42 38 58 22 50 4M50 50 C63 42 77 58 96 50" /><circle cx="50" cy="50" r="7" /></svg>
      <span className="tutorial-rotate"><RotateCw size={20} /></span>
    </div>
  );
}

export default function GameOverlay() {
  const query = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const eventMode = query.get("event") === "true";
  const demoMode = query.has("demo");
  const finalPreview = query.get("preview") === "final";
  const [phase, setPhase] = useState<Phase>(() => finalPreview ? "final" : "intro");
  const [levelIndex, setLevelIndex] = useState(0);
  const [puzzle, setPuzzle] = useState<PuzzleTile[]>(() => makePuzzle(LEVELS[0], randomSeed()));
  const [poweredIds, setPoweredIds] = useState<Set<string>>(() => new Set());
  const [moves, setMoves] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [totalScore, setTotalScore] = useState(0);
  const [lastAward, setLastAward] = useState(0);
  const [levelComplete, setLevelComplete] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [revealStep, setRevealStep] = useState(() => finalPreview ? 3 : 0);
  const [showClue, setShowClue] = useState(() => finalPreview);
  const [lightPulse, setLightPulse] = useState(0);
  const [unlockedWorlds, setUnlockedWorlds] = useState<LevelTheme[]>(() => finalPreview ? LEVELS.map((entry) => entry.theme) : []);
  const [clue, setClue] = useState<Clue>(() => CLUES[Math.floor(Math.random() * CLUES.length)]);
  const startedAt = useRef(Date.now());
  const level = LEVELS[levelIndex];
  const pathTileCount = puzzle.filter((tile) => tile.isPath).length;
  const lightProgress = pathTileCount ? poweredIds.size / pathTileCount : 0;

  const initializeLevel = useCallback((nextIndex: number) => {
    const nextLevel = LEVELS[nextIndex];
    setLevelIndex(nextIndex);
    setPuzzle(makePuzzle(nextLevel, randomSeed()));
    setPoweredIds(new Set());
    setMoves(0);
    setElapsed(0);
    setLastAward(0);
    setLightPulse(0);
    setLevelComplete(false);
    startedAt.current = Date.now();
  }, []);

  const beginGame = useCallback(() => {
    setTotalScore(0);
    setUnlockedWorlds([]);
    initializeLevel(0);
    setPhase("playing");
    startAmbientMusic(soundOn);
  }, [initializeLevel, soundOn]);

  const rotateTile = useCallback((id: string, silent = false) => {
    if (phase !== "playing" || levelComplete) return;
    const scrollTop = typeof window === "undefined" ? 0 : window.scrollY;
    const nextPuzzle = puzzle.map((tile) => tile.id === id ? { ...tile, rotation: (tile.rotation + 1) % 4, turns: tile.turns + 1 } : tile);
    const result = resolvePuzzle(level, nextPuzzle);
    const nextMoves = moves + 1;
    const gainedLight = result.poweredIds.size > poweredIds.size;

    setPuzzle(nextPuzzle);
    setPoweredIds(result.poweredIds);
    setMoves(nextMoves);
    if (gainedLight) setLightPulse((pulse) => pulse + 1);
    window.requestAnimationFrame(() => window.scrollTo({ top: scrollTop, left: 0, behavior: "auto" }));

    if (result.complete) {
      const currentSeconds = Math.max(elapsed, Math.floor((Date.now() - startedAt.current) / 1000));
      const reward = levelPoints(level, nextMoves, currentSeconds);
      setLastAward(reward);
      setTotalScore((score) => score + reward);
      setUnlockedWorlds((themes) => themes.includes(level.theme) ? themes : [...themes, level.theme]);
      setLevelComplete(true);
      if (!silent) {
        playThemeSound(level.theme, soundOn, true);
        playSound("complete", soundOn);
      }
      return;
    }

    if (!silent) {
      if (gainedLight) playThemeSound(level.theme, soundOn);
      else playSound("rotate", soundOn);
    }
  }, [elapsed, level, levelComplete, moves, phase, poweredIds.size, puzzle, soundOn]);

  const restartLevel = useCallback(() => initializeLevel(levelIndex), [initializeLevel, levelIndex]);

  useEffect(() => {
    if (phase !== "playing" || levelComplete) return;
    const tick = () => setElapsed(Math.floor((Date.now() - startedAt.current) / 1000));
    tick();
    const timer = window.setInterval(tick, 500);
    return () => window.clearInterval(timer);
  }, [levelComplete, phase]);

  useEffect(() => {
    if (!levelComplete) return;
    const delay = levelIndex === LEVELS.length - 1 ? 2800 : 2100;
    const timer = window.setTimeout(() => {
      if (levelIndex === LEVELS.length - 1) {
        setClue(CLUES[Math.floor(Math.random() * CLUES.length)]);
        setRevealStep(0);
        setShowClue(false);
        setPhase("final");
      } else {
        initializeLevel(levelIndex + 1);
      }
    }, delay);
    return () => window.clearTimeout(timer);
  }, [initializeLevel, levelComplete, levelIndex]);

  useEffect(() => {
    if (phase !== "final") return;
    const first = window.setTimeout(() => setRevealStep(1), 500);
    const second = window.setTimeout(() => setRevealStep(2), 2100);
    const third = window.setTimeout(() => setRevealStep(3), 3700);
    return () => { window.clearTimeout(first); window.clearTimeout(second); window.clearTimeout(third); };
  }, [phase]);

  useEffect(() => {
    if (!demoMode) return;
    let timer: number | undefined;
    if (phase === "intro") timer = window.setTimeout(() => setPhase("tutorial"), 500);
    if (phase === "tutorial") timer = window.setTimeout(beginGame, 500);
    return () => { if (timer) window.clearTimeout(timer); };
  }, [beginGame, demoMode, phase]);

  useEffect(() => {
    if (!demoMode || phase !== "playing" || levelComplete) return;
    const nextIncorrectTile = puzzle.find((tile) => tile.rotation !== 0);
    if (!nextIncorrectTile) return;
    const timer = window.setTimeout(() => rotateTile(nextIncorrectTile.id, true), 105);
    return () => window.clearTimeout(timer);
  }, [demoMode, levelComplete, phase, puzzle, rotateTile]);

  const sceneProgress = phase === "playing" ? lightProgress : 1;
  const backgroundStyle = {
    "--scene-image": `url(${phase === "playing" ? level.background : phase === "final" ? VISUAL_TARGET_URL : OPENING_BACKGROUND_URL})`,
    "--scene-brightness": `${0.12 + sceneProgress * 1.03}`,
    "--scene-glow": `${0.02 + sceneProgress * 0.72}`,
    "--scene-scrim": `${0.95 - sceneProgress * 0.76}`,
    "--accent": phase === "playing" ? level.accent : "#ef9b5b",
  } as CSSProperties;

  if (phase === "intro") {
    return (
      <main className={`game-shell intro-screen ${eventMode ? "event-mode" : ""}`} style={backgroundStyle}>
        <div className="screen-scrim" />
        <div className="intro-content">
          <div className="brand-lockup"><span className="brand-sigil">✦</span> PUZZLE ÉCLAT</div>
          {eventMode && <div className="mode-pill">ACTIVATION ÉVÉNEMENT</div>}
          <p className="eyebrow">TROUVER LA DERNIÈRE PIÈCE</p>
          <h1>RÉVEILLE<br /><em>L’ÉCLAT</em></h1>
          <p className="intro-copy">La lumière s’est éteinte.<br />À toi de retrouver son chemin.</p>
          <button className="primary-button intro-button" onClick={() => setPhase("tutorial")}><Sparkles size={18} /> COMMENCER</button>
          <p className="intro-footnote">Tourne les fragments · Réveille le monde</p>
        </div>
        <div className="intro-orb orb-one" /><div className="intro-orb orb-two" />
      </main>
    );
  }

  if (phase === "tutorial") {
    return (
      <main className={`game-shell tutorial-screen ${eventMode ? "event-mode" : ""}`} style={backgroundStyle}>
        <div className="screen-scrim" />
        <div className="tutorial-content">
          <div className="brand-lockup compact"><span className="brand-sigil">✦</span> PUZZLE ÉCLAT</div>
          <TutorialTile />
          <p className="eyebrow">UNE ÉTINCELLE SUFFIT</p>
          <h2>Tourne les fragments<br />pour libérer la lumière.</h2>
          <p className="tutorial-copy">À chaque bon éclat, le décor se réveille un peu plus.</p>
          <button className="primary-button" onClick={beginGame}><Lightbulb size={18} /> JOUER</button>
        </div>
      </main>
    );
  }

  if (phase === "final") {
    return (
      <main className={`game-shell final-screen ${eventMode ? "event-mode" : ""}`} style={backgroundStyle}>
        <div className="screen-scrim final-scrim" />
        <div className="final-fragments" aria-hidden="true"><span>♜</span><span>⚓</span><span>☾</span><span>⚑</span><span>❋</span></div>
        <div className="final-content">
          <div className="brand-lockup compact"><span className="brand-sigil">✦</span> PUZZLE ÉCLAT</div>
          <div className="final-center">
            <div className={`final-keychain ${revealStep >= 1 ? "is-lit" : ""}`}><KeychainCollection themes={unlockedWorlds.length ? unlockedWorlds : LEVELS.map((entry) => entry.theme)} finale /></div>
            <h2 className={`final-line ${revealStep >= 1 ? "is-visible" : ""}`}>TON PORTE-CLÉS EST COMPLET.</h2>
            <p className={`final-subline ${revealStep >= 2 ? "is-visible" : ""}`}>Mais une pièce manque encore…</p>
            <p className={`final-quest ${revealStep >= 2 ? "is-visible" : ""}`}>Ta quête continue.</p>
            {revealStep >= 3 && !showClue && <button className="primary-button clue-button" onClick={() => setShowClue(true)}><Compass size={18} /> VOIR MON INDICE</button>}
            {showClue && (
              <section className="clue-card" aria-label="Indice de quête">
                <p>TA PIÈCE</p>
                <strong>{clue.symbol} {clue.number}</strong>
                <div className="clue-details"><span>SYMBOLE <b>{clue.symbol}</b></span>{eventMode && <span>DIRECTION <b>{clue.direction}</b></span>}</div>
                <small>{eventMode ? "Retrouve cette pièce dans le labyrinthe." : "Garde précieusement cet indice pour la suite de l’aventure."}</small>
              </section>
            )}
            {showClue && <button className="secondary-button replay-button" onClick={() => { setPhase("intro"); setLevelIndex(0); }}>REJOUER</button>}
            {revealStep >= 3 && <p className="final-score">{rankFor(totalScore)} · {totalScore.toLocaleString("fr-FR")} ÉCLATS</p>}
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className={`game-shell play-screen ${levelComplete ? "is-world-awake" : ""} ${eventMode ? "event-mode" : ""}`} style={backgroundStyle}>
      <div className="play-scrim" />
      <div className="scene-light-wash" aria-hidden="true" />
      {lightPulse > 0 && <div className="light-connection-burst" key={lightPulse} aria-hidden="true" />}
      {levelComplete && <div className="world-awake-flash" aria-hidden="true" />}
      <header className="game-hud">
        <div className="brand-lockup compact"><span className="brand-sigil">✦</span> <span className="desktop-brand">PUZZLE ÉCLAT</span></div>
        <div className="level-hud"><span>NIVEAU {level.id} / {LEVELS.length}</span><b>{level.world}</b></div>
        <div className="hud-actions">
          {demoMode && <span className="demo-pill">DÉMO</span>}
          <button className="icon-button" onClick={() => setSoundOn((value) => { const next = !value; if (next) startAmbientMusic(true); else stopAmbientMusic(); return next; })} aria-label={soundOn ? "Couper le son" : "Activer le son"}>{soundOn ? <Volume2 size={18} /> : <VolumeX size={18} />}</button>
        </div>
      </header>
      <section className="play-layout">
        <div className="level-intro">
          <p className="eyebrow">{level.difficulty}</p>
          <h2>{level.title}</h2>
          <p>{level.subtitle}</p>
          <div className="level-tip"><Lightbulb size={16} /> {level.tip}</div>
          <SceneReveal level={level} progress={lightProgress} />
        </div>
        <PuzzleBoard level={level} puzzle={puzzle} poweredIds={poweredIds} locked={levelComplete} onRotate={rotateTile} />
        <aside className="stats-panel" aria-label="Statistiques de jeu">
          <div><Timer size={16} /><span>TEMPS</span><b>{formatTime(elapsed)}</b></div>
          <div><RotateCw size={16} /><span>MOUVEMENTS</span><b>{moves}</b></div>
          <div><Sparkles size={16} /><span>ÉCLATS</span><b>{totalScore.toLocaleString("fr-FR")}</b></div>
          <button className="restart-button" onClick={restartLevel}><RotateCcw size={15} /> RECOMMENCER</button>
        </aside>
      </section>
      <div className="tap-prompt"><RotateCw size={16} /> Touchez un fragment pour le faire tourner</div>
      {levelComplete && <div className="completion-banner" role="status"><KeychainCollection themes={[level.theme]} /><div><b>UNE PIÈCE REJOINT LE PORTE-CLÉS</b><span>{level.objective} est réveillé · + {lastAward} ÉCLATS</span></div></div>}
    </main>
  );
}
