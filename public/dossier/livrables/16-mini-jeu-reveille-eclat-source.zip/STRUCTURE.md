# Réveille l’Éclat — Runtime Structure

```text
client/src/
├── components/
│   ├── GameCanvas.tsx      # Babylon lifecycle-safe canvas host
│   └── GameOverlay.tsx     # React experience, HUD, screens, and puzzle board
├── game/
│   ├── levels.ts           # Five themed, data-driven level configurations
│   ├── puzzle.ts           # Rotation, seeded setup, BFS power propagation
│   ├── scene.ts            # Lightweight Babylon starfield layer
│   └── audio.ts            # Gesture-safe soft chime system
├── App.tsx                 # Sole GameCanvas route
└── index.css               # Responsive visual system and animation rules
```

## Runtime ownership

| Module | Owns | Does not own |
| --- | --- | --- |
| `levels.ts` | Theme copy, backgrounds, paths, source and target positions | Mutable game state |
| `puzzle.ts` | Tile topology, rotation transformations, validity and powered tiles | DOM / React concerns |
| `GameOverlay.tsx` | Phase machine, score, timer, user actions, render state | Circuit algorithm |
| `scene.ts` | Babylon scene, ambient stars and cleanup | Puzzle UI or input |
| `GameCanvas.tsx` | One Babylon engine, resize listener, render-loop lifecycle | Game state |

## Asset hints

| Asset | Role | Display size |
| --- | --- | --- |
| Generated themed scene plates | Visual world behind each playable board | Full viewport, `cover` |
| Generated visual target | Intro/finale mural | Full viewport, `cover` |
| DOM/SVG puzzle circuits | Crisp interactive light paths | 56–120 px per tile depending on viewport |

The game uses DOM SVG for interactive tiles so every path remains crisp, keyboard-accessible and responsive; Babylon contributes the atmospheric full-screen starfield behind the interface.
